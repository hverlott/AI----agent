#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
多平台社交媒体 AI Bot - 统一管理后台
支持 Telegram, WhatsApp, Facebook, Messenger, 微信等
"""

import streamlit as st
import os
import sys
import json
import re
from datetime import datetime

# 页面配置
st.set_page_config(
    page_title="👑鼎盛👑内部工具",
    page_icon="👑",
    layout="wide",
    initial_sidebar_state="expanded"
)

# CSS 样式（优化紧凑版）
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        font-weight: bold;
        text-align: center;
        background: linear-gradient(120deg, #1f77b4, #ff7f0e);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        margin-bottom: 1.5rem;
    }
    .platform-card {
        padding: 1rem;
        border-radius: 8px;
        border: 2px solid #e0e0e0;
        margin: 0.3rem 0;
        transition: all 0.3s;
    }
    .platform-card:hover {
        border-color: #1f77b4;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    .platform-active {
        border-color: #1f77b4 !important;
        background-color: #f0f8ff;
    }
    .status-badge {
        display: inline-block;
        padding: 0.2rem 0.5rem;
        border-radius: 10px;
        font-size: 0.75rem;
        font-weight: bold;
    }
    .status-running {
        background-color: #d4edda;
        color: #155724;
    }
    .status-stopped {
        background-color: #f8d7da;
        color: #721c24;
    }
    .status-pending {
        background-color: #fff3cd;
        color: #856404;
    }
    /* 紧凑侧边栏样式 */
    [data-testid="stSidebar"] {
        padding-top: 2rem;
    }
    [data-testid="stSidebar"] .element-container {
        margin-bottom: 0.3rem;
    }
    [data-testid="stSidebar"] button {
        padding: 0.3rem 0.5rem;
        font-size: 0.85rem;
    }
    [data-testid="stSidebar"] small {
        font-size: 0.85rem;
    }
</style>
""", unsafe_allow_html=True)

# 平台配置
PLATFORMS = {
    'telegram': {
        'name': 'Telegram',
        'icon': '📱',
        'color': '#0088cc',
        'status': 'available',  # available, unavailable, coming_soon
        'description': '全功能支持 - 私聊/群聊/频道'
    },
    'whatsapp': {
        'name': 'WhatsApp',
        'icon': '💬',
        'color': '#25D366',
        'status': 'available',
        'description': '✅ 可用 - 私聊/群聊自动回复'
    },
    'facebook': {
        'name': 'Facebook',
        'icon': '📘',
        'color': '#1877f2',
        'status': 'coming_soon',
        'description': '规划中 - Messenger + 主页'
    },
    'messenger': {
        'name': 'Messenger',
        'icon': '💙',
        'color': '#006aff',
        'status': 'coming_soon',
        'description': '规划中 - 独立客户端'
    },
    'wechat': {
        'name': '微信 WeChat',
        'icon': '💚',
        'color': '#07c160',
        'status': 'coming_soon',
        'description': '规划中 - 个人号/公众号'
    },
    'instagram': {
        'name': 'Instagram',
        'icon': '📷',
        'color': '#E4405F',
        'status': 'coming_soon',
        'description': '规划中 - DM 自动回复'
    },
    'twitter': {
        'name': 'Twitter/X',
        'icon': '🐦',
        'color': '#1DA1F2',
        'status': 'coming_soon',
        'description': '规划中 - DM + 提及回复'
    },
    'discord': {
        'name': 'Discord',
        'icon': '💜',
        'color': '#5865F2',
        'status': 'coming_soon',
        'description': '规划中 - 服务器 Bot'
    }
}

TG_GROUP_CACHE_FILE = "platforms/telegram/group_cache.json"
TG_SELECTED_GROUPS_FILE = "platforms/telegram/selected_groups.json"

def load_platform_config(platform):
    """加载平台配置"""
    config_file = f"platforms/{platform}/config.json"
    try:
        if os.path.exists(config_file):
            with open(config_file, 'r', encoding='utf-8') as f:
                return json.load(f)
    except:
        pass
    return {}

def save_platform_config(platform, config):
    """保存平台配置"""
    config_file = f"platforms/{platform}/config.json"
    os.makedirs(os.path.dirname(config_file), exist_ok=True)
    with open(config_file, 'w', encoding='utf-8') as f:
        json.dump(config, f, indent=2, ensure_ascii=False)


def load_tg_group_cache():
    try:
        with open(TG_GROUP_CACHE_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
            if isinstance(data, dict):
                return data
    except:
        pass
    return {}


def load_tg_selected_groups():
    try:
        with open(TG_SELECTED_GROUPS_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
            return data.get('selected_ids', [])
    except:
        return []


def save_tg_selected_groups(selected_ids):
    os.makedirs(os.path.dirname(TG_SELECTED_GROUPS_FILE), exist_ok=True)
    with open(TG_SELECTED_GROUPS_FILE, 'w', encoding='utf-8') as f:
        json.dump({'selected_ids': selected_ids}, f, ensure_ascii=False, indent=2)


def parse_group_ids(raw_text):
    if not raw_text:
        return []
    entries = re.split(r'[,\s]+', raw_text.strip())
    ids = []
    for token in entries:
        if not token:
            continue
        try:
            ids.append(int(token))
        except:
            continue
    return ids

def render_platform_selector():
    """渲染平台选择器（优化紧凑版）"""
    st.sidebar.markdown("### 🌐 平台")
    
    selected_platform = st.session_state.get('selected_platform', 'telegram')
    
    for platform_id, platform_info in PLATFORMS.items():
        # 创建紧凑的平台选项
        col1, col2, col3 = st.sidebar.columns([1, 3, 1])
        
        with col1:
            st.markdown(f"<div style='font-size: 1.5rem;'>{platform_info['icon']}</div>", 
                      unsafe_allow_html=True)
        
        with col2:
            st.markdown(f"<small>**{platform_info['name']}**</small>", 
                      unsafe_allow_html=True)
        
        with col3:
            # 状态标识（简化版）
            if platform_info['status'] == 'available':
                st.markdown("🟢", unsafe_allow_html=True)
            elif platform_info['status'] == 'coming_soon':
                st.markdown("🟡", unsafe_allow_html=True)
            else:
                st.markdown("🔴", unsafe_allow_html=True)
        
        # 选择按钮（紧凑版）
        button_label = "✓" if selected_platform == platform_id else "选择"
        if st.sidebar.button(
            button_label,
            key=f"select_{platform_id}",
            disabled=(platform_info['status'] != 'available'),
            use_container_width=True,
            type="primary" if selected_platform == platform_id else "secondary"
        ):
            st.session_state.selected_platform = platform_id
            st.rerun()
    
    return selected_platform

def render_telegram_panel():
    """渲染 Telegram 控制面板"""
    from admin import (
        get_bot_status, start_bot, stop_bot, 
        read_file, write_file, read_logs
    )
    
    st.header("📱 Telegram AI Bot 控制面板")
    
    # 状态显示
    col1, col2, col3 = st.columns(3)
    
    with col1:
        is_running, pid = get_bot_status()
        if is_running:
            st.success(f"🟢 运行中 (PID: {pid})")
        else:
            st.error("🔴 已停止")
    
    with col2:
        if os.path.exists("userbot_session.session"):
            st.success("✅ 已登录")
        else:
            st.warning("⚠️ 未登录")
    
    with col3:
        if os.path.exists(".env"):
            st.success("✅ 已配置")
        else:
            st.error("❌ 未配置")
    
    st.divider()
    
    # 控制按钮
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if st.button("🚀 启动机器人", use_container_width=True, type="primary", 
                    disabled=is_running):
            success, message = start_bot()
            if success:
                st.success(message)
                st.rerun()
            else:
                st.error(message)
    
    with col2:
        if st.button("⛔ 停止机器人", use_container_width=True, 
                    disabled=not is_running):
            success, message = stop_bot()
            if success:
                st.success(message)
                st.rerun()
            else:
                st.error(message)
    
    with col3:
        if st.button("🔄 重启机器人", use_container_width=True,
                    disabled=not is_running):
            stop_bot()
            import time
            time.sleep(1)
            start_bot()
            st.success("机器人已重启")
            st.rerun()
    
    st.divider()
    
    # Tab 界面
    tab1, tab2, tab3, tab4 = st.tabs([
        "🧠 配置", "📢 群发", "📜 日志", "📊 统计"
    ])
    
    with tab1:
        render_telegram_config()
    
    with tab2:
        st.info("💡 群发功能请使用原管理后台 (admin.py)")
        if st.button("打开原管理后台", use_container_width=True):
            st.info("请在新标签页打开: streamlit run admin.py --server.port 8502")
    
    with tab3:
        render_telegram_logs()
    
    with tab4:
        render_telegram_stats()

def render_telegram_config():
    """Telegram 配置界面"""
    from admin import read_file, write_file
    
    st.subheader("⚙️ 配置管理")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("**AI 人设**")
        prompt = st.text_area(
            "编辑提示词",
            value=read_file("prompt.txt"),
            height=200,
            key="tg_prompt"
        )
        if st.button("💾 保存人设", key="save_prompt"):
            write_file("prompt.txt", prompt)
            st.success("✅ 已保存")
    
    with col2:
        st.markdown("**触发关键词**")
        keywords = st.text_area(
            "每行一个",
            value=read_file("keywords.txt", "帮我\n求助\nAI"),
            height=200,
            key="tg_keywords"
        )
        if st.button("💾 保存关键词", key="save_keywords"):
            write_file("keywords.txt", keywords)
            st.success("✅ 已保存")
    
    st.divider()
    
    # 功能开关
    st.markdown("**功能开关**")
    config_content = read_file("platforms/telegram/config.txt", "PRIVATE_REPLY=on\nGROUP_REPLY=on")
    
    current_config = {
        'PRIVATE_REPLY': True,
        'GROUP_REPLY': True,
        'GROUP_CONTEXT': False
    }
    for line in config_content.split('\n'):
        if '=' in line and not line.strip().startswith('#'):
            key, value = line.split('=', 1)
            key = key.strip()
            value = value.strip().lower()
            if key in current_config:
                current_config[key] = (value == 'on')
    
    col1, col2 = st.columns(2)
    
    with col1:
        private_reply = st.toggle(
            "私聊自动回复",
            value=current_config['PRIVATE_REPLY'],
            key="tg_private"
        )
    
    with col2:
        group_reply = st.toggle(
            "群聊自动回复",
            value=current_config['GROUP_REPLY'],
            key="tg_group"
        )
    
    context_reply = st.toggle(
        "群聊上下文自动回复",
        value=current_config['GROUP_CONTEXT'],
        key="tg_context"
    )
    st.caption("开启后即使消息未命中关键词或 @ 也会结合上下文回复，关闭时仍需关键词/@ 触发。")

    if st.button("💾 保存开关", use_container_width=True):
        new_config = (
            f"PRIVATE_REPLY={'on' if private_reply else 'off'}\n"
            f"GROUP_REPLY={'on' if group_reply else 'off'}\n"
            f"GROUP_CONTEXT={'on' if context_reply else 'off'}"
        )
        write_file("platforms/telegram/config.txt", new_config)
        st.success("✅ 已保存")

    st.divider()
    st.markdown("**群聊白名单**")
    st.caption("选择的群聊才能自动回复，留空时默认遵循 GROUP_REPLY 开关对所有群聊有效。")

    selected_group_ids = load_tg_selected_groups()
    group_cache = load_tg_group_cache()
    group_rows = []
    display_map = {}

    if group_cache:
        sorted_cache = sorted(
            group_cache.items(),
            key=lambda kv: (kv[1].get('title') or "").lower()
        )
        for chat_id_str, detail in sorted_cache:
            try:
                chat_id = int(chat_id_str)
            except:
                continue

            title = detail.get('title') or "未命名群聊"
            last_seen = detail.get('last_seen') or "未知"
            group_rows.append({
                "群名称": title,
                "群 ID": chat_id,
                "最近活跃": last_seen
            })
            display_label = f"{title} ({chat_id})"
            display_map[display_label] = chat_id

        if group_rows:
            st.table(group_rows)
    else:
        st.info("机器人尚未缓存任何群聊，先接收群消息后再回来配置白名单。")

    selected_from_list = []
    if display_map:
        default_displays = [
            label for label, gid in display_map.items()
            if gid in selected_group_ids
        ]
        picked = st.multiselect(
            "选中的群聊",
            options=list(display_map.keys()),
            default=default_displays,
            key="tg_group_whitelist"
        )
        selected_from_list = [
            display_map[label] for label in picked if label in display_map
        ]

    known_ids = set(display_map.values())
    manual_unknown = sorted(
        gid for gid in selected_group_ids if gid not in known_ids
    )
    manual_value = "\n".join(str(gid) for gid in manual_unknown)
    manual_input = st.text_area(
        "补充群 ID（未在列表中的群，可在此填写，支持换行或逗号分隔）",
        value=manual_value,
        height=100,
        placeholder="-1001234567890\n-1009876543210"
    )

    if st.button("💾 保存群聊白名单", use_container_width=True):
        manual_ids = parse_group_ids(manual_input)
        combined = sorted(set(selected_from_list + manual_ids))
        save_tg_selected_groups(combined)
        st.success("✅ 群聊白名单已保存，仅选中群聊会自动回复")
        st.rerun()

def render_telegram_logs():
    """Telegram 日志界面"""
    from admin import read_logs, BOT_LOG_FILE
    
    st.subheader("📜 运行日志")
    
    col1, col2 = st.columns([4, 1])
    
    with col2:
        if st.button("🔄 刷新", use_container_width=True):
            st.rerun()
    
    logs = read_logs(100)
    st.text_area("日志内容", value=logs, height=400, disabled=True, label_visibility="hidden")
    
    if st.button("🗑️ 清空日志", use_container_width=True):
        try:
            open(BOT_LOG_FILE, 'w').close()
            st.success("✅ 已清空")
            st.rerun()
        except:
            st.error("❌ 清空失败")

def render_telegram_stats():
    """Telegram 统计界面"""
    st.subheader("📊 使用统计")
    
    # 读取统计数据
    try:
        import json
        from datetime import datetime
        with open("platforms/telegram/stats.json", 'r', encoding='utf-8') as f:
            stats = json.load(f)
        
        # 计算成功率
        success_rate = 0
        if stats['total_replies'] > 0:
            success_rate = (stats['success_count'] / stats['total_replies']) * 100
        
        # 显示统计
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric("总消息数", stats['total_messages'])
        
        with col2:
            st.metric("总回复数", stats['total_replies'])
        
        with col3:
            st.metric("成功率", f"{success_rate:.1f}%")
        
        with col4:
            st.metric("失败次数", stats['error_count'])
        
        st.divider()
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.metric("私聊消息", stats['private_messages'])
        
        with col2:
            st.metric("群聊消息", stats['group_messages'])
        
        # 运行时间
        if stats.get('start_time'):
            start_time = datetime.fromisoformat(stats['start_time'])
            running_time = datetime.now() - start_time
            days = running_time.days
            hours = running_time.seconds // 3600
            minutes = (running_time.seconds % 3600) // 60
            
            st.divider()
            st.info(f"⏱️ 运行时长: {days}天 {hours}小时 {minutes}分钟")
        
        if stats.get('last_active'):
            last_active = datetime.fromisoformat(stats['last_active'])
            st.caption(f"最后活跃: {last_active.strftime('%Y-%m-%d %H:%M:%S')}")
        
        # 重置按钮
        if st.button("🗑️ 重置统计", use_container_width=True):
            default_stats = {
                "total_messages": 0,
                "total_replies": 0,
                "private_messages": 0,
                "group_messages": 0,
                "success_count": 0,
                "error_count": 0,
                "start_time": datetime.now().isoformat(),
                "last_active": None
            }
            with open("platforms/telegram/stats.json", 'w', encoding='utf-8') as f:
                json.dump(default_stats, f, indent=2, ensure_ascii=False)
            st.success("✅ 统计已重置")
            st.rerun()
        
    except Exception as e:
        st.error(f"读取统计失败: {e}")
        st.info("💡 统计数据将在机器人运行后生成")

# ==================== WhatsApp 面板 ====================

def get_whatsapp_status():
    """获取 WhatsApp 机器人运行状态"""
    pid_file = "platforms/whatsapp/bot.pid"
    try:
        if os.path.exists(pid_file):
            with open(pid_file, 'r') as f:
                pid = int(f.read().strip())
            try:
                import psutil
                if psutil.pid_exists(pid):
                    return True, pid
            except:
                pass
        return False, None
    except:
        return False, None

def start_whatsapp_bot():
    """启动 WhatsApp 机器人"""
    try:
        # 检查 Node.js
        import subprocess
        result = subprocess.run(['node', '--version'], capture_output=True, text=True)
        if result.returncode != 0:
            return False, "❌ 未检测到 Node.js，请先安装"
        
        # 检查依赖
        if not os.path.exists("platforms/whatsapp/node_modules"):
            return False, "❌ 请先运行 install.bat/sh 安装依赖"
        
        # 启动机器人
        whatsapp_dir = "platforms/whatsapp"
        log_file = os.path.join(whatsapp_dir, "bot.log")
        pid_file = os.path.join(whatsapp_dir, "bot.pid")
        
        # 清理旧文件（避免权限问题）
        try:
            if os.path.exists(log_file):
                os.remove(log_file)
            if os.path.exists(pid_file):
                os.remove(pid_file)
        except:
            pass
        
        # 使用 'a' 模式而不是 'w'，避免权限问题
        log_handle = open(log_file, 'a', encoding='utf-8', buffering=1)
        
        if sys.platform == 'win32':
            process = subprocess.Popen(
                ['node', 'bot.js'],
                cwd=whatsapp_dir,
                stdout=log_handle,
                stderr=subprocess.STDOUT,
                creationflags=subprocess.CREATE_NO_WINDOW
            )
        else:
            process = subprocess.Popen(
                ['node', 'bot.js'],
                cwd=whatsapp_dir,
                stdout=log_handle,
                stderr=subprocess.STDOUT
            )
        
        # 保存 PID
        with open(pid_file, 'w') as f:
            f.write(str(process.pid))
        
        # 注意：不要关闭 log_handle，让进程继续使用
        
        return True, f"✅ WhatsApp 机器人已启动 (PID: {process.pid})"
    except Exception as e:
        return False, f"❌ 启动失败: {str(e)}"

def stop_whatsapp_bot():
    """停止 WhatsApp 机器人"""
    pid_file = "platforms/whatsapp/bot.pid"
    try:
        if os.path.exists(pid_file):
            with open(pid_file, 'r') as f:
                pid = int(f.read().strip())
            
            import psutil
            if psutil.pid_exists(pid):
                process = psutil.Process(pid)
                process.terminate()
                process.wait(timeout=5)
            
            os.remove(pid_file)
            return True, "✅ WhatsApp 机器人已停止"
        else:
            return False, "⚠️ 机器人未在运行"
    except Exception as e:
        return False, f"❌ 停止失败: {str(e)}"

def render_whatsapp_panel():
    """WhatsApp 主面板"""
    st.header("💬 WhatsApp 自动回复机器人")
    
    # 检查是否有二维码需要显示
    qr_image_path = "platforms/whatsapp/qr_code.png"
    status_file_path = "platforms/whatsapp/login_status.json"
    
    # 显示二维码弹窗
    if os.path.exists(qr_image_path) and os.path.exists(status_file_path):
        try:
            import json
            with open(status_file_path, 'r') as f:
                login_status = json.load(f)
            
            if login_status.get('status') == 'waiting' and login_status.get('qr_available'):
                with st.expander("📱 WhatsApp 登录二维码", expanded=True):
                    st.info("请使用手机 WhatsApp 扫描下方二维码登录")
                    st.image(qr_image_path, caption="扫描此二维码登录", width=400)
                    st.caption("提示：打开 WhatsApp > 设置 > 已连接的设备 > 连接设备")
                    st.caption("⏳ 二维码有效期约 20 秒，过期请重启机器人")
                    
                    if st.button("🔄 刷新查看状态", key="refresh_qr"):
                        st.rerun()
        except Exception as e:
            st.error(f"读取登录状态失败: {e}")
    
    # 状态显示
    col1, col2, col3 = st.columns(3)
    
    with col1:
        is_running, pid = get_whatsapp_status()
        if is_running:
            st.success(f"🟢 运行中 (PID: {pid})")
        else:
            st.error("🔴 已停止")
    
    with col2:
        if os.path.exists("platforms/whatsapp/.wwebjs_auth"):
            st.success("✅ 已登录")
        else:
            st.warning("⚠️ 未登录")
    
    with col3:
        if os.path.exists(".env"):
            st.success("✅ 已配置")
        else:
            st.error("❌ 未配置")
    
    st.divider()
    
    # 控制按钮
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if st.button("🚀 启动机器人", use_container_width=True, type="primary", 
                    disabled=is_running, key="whatsapp_start"):
            success, message = start_whatsapp_bot()
            if success:
                st.success(message)
                st.rerun()
            else:
                st.error(message)
    
    with col2:
        if st.button("⛔ 停止机器人", use_container_width=True, 
                    disabled=not is_running, key="whatsapp_stop"):
            success, message = stop_whatsapp_bot()
            if success:
                st.success(message)
                st.rerun()
            else:
                st.error(message)
    
    with col3:
        if st.button("🔄 重启机器人", use_container_width=True,
                    disabled=not is_running, key="whatsapp_restart"):
            stop_whatsapp_bot()
            import time
            time.sleep(1)
            start_whatsapp_bot()
            st.success("机器人已重启")
            st.rerun()
    
    st.divider()
    
    # Tab 界面
    tab1, tab2, tab3 = st.tabs([
        "🧠 配置", "📜 日志", "📊 统计"
    ])
    
    with tab1:
        render_whatsapp_config()
    
    with tab2:
        render_whatsapp_logs()
    
    with tab3:
        render_whatsapp_stats()

def render_whatsapp_config():
    """WhatsApp 配置界面"""
    from admin import read_file, write_file
    
    st.subheader("⚙️ 配置管理")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("**AI 人设**")
        prompt = st.text_area(
            "编辑提示词",
            value=read_file("platforms/whatsapp/prompt.txt", "你是一个幽默的助手"),
            height=200,
            key="wa_prompt"
        )
        if st.button("💾 保存人设", key="wa_save_prompt"):
            write_file("platforms/whatsapp/prompt.txt", prompt)
            st.success("✅ 已保存")
    
    with col2:
        st.markdown("**触发关键词**")
        keywords = st.text_area(
            "群聊关键词（每行一个）",
            value=read_file("platforms/whatsapp/keywords.txt", "帮我\n求助\nAI"),
            height=200,
            key="wa_keywords"
        )
        if st.button("💾 保存关键词", key="wa_save_keywords"):
            write_file("platforms/whatsapp/keywords.txt", keywords)
            st.success("✅ 已保存")
    
    st.divider()
    
    st.markdown("**功能开关**")
    config_content = read_file("platforms/whatsapp/config.txt", "PRIVATE_REPLY=on\nGROUP_REPLY=on")
    
    col1, col2 = st.columns(2)
    
    with col1:
        private_reply = "on" if "PRIVATE_REPLY=on" in config_content else "off"
        private_enabled = st.toggle("私聊回复", value=(private_reply=="on"), key="wa_private")
    
    with col2:
        group_reply = "on" if "GROUP_REPLY=on" in config_content else "off"
        group_enabled = st.toggle("群聊回复", value=(group_reply=="on"), key="wa_group")
    
    if st.button("💾 保存开关配置", key="wa_save_config"):
        new_config = f"PRIVATE_REPLY={'on' if private_enabled else 'off'}\nGROUP_REPLY={'on' if group_enabled else 'off'}"
        write_file("platforms/whatsapp/config.txt", new_config)
        st.success("✅ 已保存")
    
    st.info("💡 修改后立即生效，无需重启机器人")

def render_whatsapp_logs():
    """WhatsApp 日志界面"""
    st.subheader("📜 运行日志")
    
    log_file = "platforms/whatsapp/bot.log"
    
    col1, col2 = st.columns([3, 1])
    
    with col1:
        if os.path.exists(log_file):
            file_size = os.path.getsize(log_file)
            last_modified = datetime.fromtimestamp(os.path.getmtime(log_file))
            st.caption(f"📁 文件大小: {file_size} 字节 | 📅 最后更新: {last_modified.strftime('%Y-%m-%d %H:%M:%S')}")
    
    with col2:
        if st.button("🔄 刷新日志", use_container_width=True, key="wa_refresh"):
            st.rerun()
    
    try:
        if os.path.exists(log_file):
            with open(log_file, 'r', encoding='utf-8', errors='ignore') as f:
                logs = f.read()
            
            if logs.strip():
                st.code(logs, language="log", line_numbers=False)
            else:
                st.info("📝 日志为空，等待机器人产生输出...")
        else:
            st.warning("⚠️ 日志文件不存在，请先启动机器人")
    except Exception as e:
        st.error(f"❌ 读取日志失败: {e}")
    
    if st.button("🗑️ 清空日志", key="wa_clear"):
        try:
            with open(log_file, 'w') as f:
                f.write("")
            st.success("✅ 日志已清空")
            st.rerun()
        except:
            st.error("❌ 清空失败")

def render_whatsapp_stats():
    """WhatsApp 统计界面"""
    st.subheader("📊 使用统计")
    
    # 读取统计数据
    try:
        import json
        from datetime import datetime
        with open("platforms/whatsapp/stats.json", 'r', encoding='utf-8') as f:
            stats = json.load(f)
        
        # 计算成功率
        success_rate = 0
        if stats['total_replies'] > 0:
            success_rate = (stats['success_count'] / stats['total_replies']) * 100
        
        # 显示统计
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric("总消息数", stats['total_messages'])
        
        with col2:
            st.metric("总回复数", stats['total_replies'])
        
        with col3:
            st.metric("成功率", f"{success_rate:.1f}%")
        
        with col4:
            st.metric("失败次数", stats['error_count'])
        
        st.divider()
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.metric("私聊消息", stats['private_messages'])
        
        with col2:
            st.metric("群聊消息", stats['group_messages'])
        
        # 运行时间
        if stats.get('start_time'):
            start_time = datetime.fromisoformat(stats['start_time'])
            running_time = datetime.now() - start_time
            days = running_time.days
            hours = running_time.seconds // 3600
            minutes = (running_time.seconds % 3600) // 60
            
            st.divider()
            st.info(f"⏱️ 运行时长: {days}天 {hours}小时 {minutes}分钟")
        
        if stats.get('last_active'):
            last_active = datetime.fromisoformat(stats['last_active'])
            st.caption(f"最后活跃: {last_active.strftime('%Y-%m-%d %H:%M:%S')}")
        
        # 重置按钮
        if st.button("🗑️ 重置统计", use_container_width=True, key="wa_reset_stats"):
            default_stats = {
                "total_messages": 0,
                "total_replies": 0,
                "private_messages": 0,
                "group_messages": 0,
                "success_count": 0,
                "error_count": 0,
                "start_time": datetime.now().isoformat(),
                "last_active": None
            }
            with open("platforms/whatsapp/stats.json", 'w', encoding='utf-8') as f:
                json.dump(default_stats, f, indent=2, ensure_ascii=False)
            st.success("✅ 统计已重置")
            st.rerun()
        
    except Exception as e:
        st.error(f"读取统计失败: {e}")
        st.info("💡 统计数据将在机器人运行后生成")

def render_coming_soon_panel(platform_name, platform_info):
    """渲染开发中的平台面板"""
    st.header(f"{platform_info['icon']} {platform_name} - 开发中")
    
    st.info(f"""
    ### 🚧 平台开发中
    
    **{platform_name}** 功能正在开发中，敬请期待！
    
    **计划功能：**
    - ✅ 自动回复
    - ✅ 上下文记忆
    - ✅ 群发消息
    - ✅ Web 管理
    - ✅ 统计报表
    
    **预计上线：** 待定
    
    ---
    
    💡 如果你急需此平台支持，请联系开发者。
    """)
    
    # 开发进度
    st.markdown("### 📈 开发进度")
    
    progress_data = {
        'whatsapp': 30,
        'facebook': 10,
        'messenger': 10,
        'wechat': 5,
        'instagram': 5,
        'twitter': 5,
        'discord': 5
    }
    
    progress = progress_data.get(platform_info.get('id', ''), 0)
    st.progress(progress / 100)
    st.caption(f"完成度: {progress}%")

def main():
    """主函数"""
    # 标题
    st.markdown('<div class="main-header">👑鼎盛👑内部工具</div>', 
                unsafe_allow_html=True)
    
    # 初始化 session state
    if 'selected_platform' not in st.session_state:
        st.session_state.selected_platform = 'telegram'
    
    # 左侧平台选择器
    selected_platform = render_platform_selector()
    
    # 侧边栏底部信息
    st.sidebar.markdown("---")
    st.sidebar.markdown("### 📊 系统信息")
    st.sidebar.caption(f"Python: {sys.version.split()[0]}")
    st.sidebar.caption(f"Streamlit: {st.__version__}")
    
    # 右侧主面板
    platform_info = PLATFORMS[selected_platform]
    
    if platform_info['status'] == 'available':
        if selected_platform == 'telegram':
            render_telegram_panel()
        elif selected_platform == 'whatsapp':
            render_whatsapp_panel()
        else:
            render_coming_soon_panel(platform_info['name'], {**platform_info, 'id': selected_platform})
    else:
        render_coming_soon_panel(platform_info['name'], {**platform_info, 'id': selected_platform})
    
    # 页脚
    st.markdown("---")
    st.caption("💡 提示：点击左侧选择不同的社交媒体平台")

if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        st.error(f"❌ 程序错误: {e}")
        import traceback
        st.code(traceback.format_exc())


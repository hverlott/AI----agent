#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Telegram AI Bot - Web 管理后台
基于 Streamlit 构建的图形化控制面板
"""

import streamlit as st
import os
import sys
import time
import random
import asyncio
import subprocess
import signal
from pathlib import Path
from datetime import datetime
from dotenv import load_dotenv

# Telethon 相关导入
from telethon import TelegramClient
from telethon.tl.functions.messages import GetDialogFiltersRequest
from telethon.tl.types import DialogFilter
from telethon.errors import FloodWaitError, PeerFloodError

# 加载环境变量
load_dotenv()

# 页面配置
st.set_page_config(
    page_title="Telegram AI 中控台",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded"
)

# CSS 样式优化
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        font-weight: bold;
        text-align: center;
        color: #1f77b4;
        margin-bottom: 2rem;
    }
    .status-running {
        color: #28a745;
        font-size: 1.2rem;
        font-weight: bold;
    }
    .status-stopped {
        color: #dc3545;
        font-size: 1.2rem;
        font-weight: bold;
    }
    .stButton>button {
        width: 100%;
        border-radius: 10px;
        height: 3em;
        font-weight: bold;
    }
    .success-box {
        padding: 1rem;
        border-radius: 5px;
        background-color: #d4edda;
        border: 1px solid #c3e6cb;
        color: #155724;
    }
    .warning-box {
        padding: 1rem;
        border-radius: 5px;
        background-color: #fff3cd;
        border: 1px solid #ffeeba;
        color: #856404;
    }
</style>
""", unsafe_allow_html=True)

# 全局变量
BOT_PID_FILE = "bot.pid"
BOT_LOG_FILE = "bot.log"

# ==================== 工具函数 ====================

def get_bot_status():
    """检查机器人运行状态"""
    if not os.path.exists(BOT_PID_FILE):
        return False, None
    
    try:
        with open(BOT_PID_FILE, 'r') as f:
            pid = int(f.read().strip())
        
        # 检查进程是否存在
        if sys.platform == 'win32':
            import psutil
            return psutil.pid_exists(pid), pid
        else:
            os.kill(pid, 0)
            return True, pid
    except (ValueError, ProcessLookupError, OSError):
        return False, None


def start_bot():
    """启动机器人"""
    is_running, _ = get_bot_status()
    if is_running:
        return False, "机器人已在运行中"
    
    try:
        # 启动 main.py 并重定向输出到日志文件
        # 使用 -u 参数强制 unbuffered 输出，确保日志实时写入
        with open(BOT_LOG_FILE, 'w', encoding='utf-8') as log_file:
            if sys.platform == 'win32':
                process = subprocess.Popen(
                    ['python', '-u', 'main.py'],  # 添加 -u 参数
                    stdout=log_file,
                    stderr=subprocess.STDOUT,
                    creationflags=subprocess.CREATE_NEW_PROCESS_GROUP,
                    bufsize=1,  # 行缓冲
                    universal_newlines=True
                )
            else:
                process = subprocess.Popen(
                    ['python', '-u', 'main.py'],  # 添加 -u 参数
                    stdout=log_file,
                    stderr=subprocess.STDOUT,
                    preexec_fn=os.setpgrp,
                    bufsize=1,  # 行缓冲
                    universal_newlines=True
                )
        
        # 保存 PID
        with open(BOT_PID_FILE, 'w') as f:
            f.write(str(process.pid))
        
        # 等待一小段时间，确保进程启动
        time.sleep(0.5)
        
        return True, f"机器人已启动 (PID: {process.pid})\n提示：日志可能需要 2-3 秒后才会显示"
    except Exception as e:
        return False, f"启动失败: {e}"


def stop_bot():
    """停止机器人"""
    is_running, pid = get_bot_status()
    if not is_running:
        return False, "机器人未在运行"
    
    try:
        if sys.platform == 'win32':
            import psutil
            process = psutil.Process(pid)
            process.terminate()
            process.wait(timeout=5)
        else:
            os.kill(pid, signal.SIGTERM)
            time.sleep(1)
        
        # 删除 PID 文件
        if os.path.exists(BOT_PID_FILE):
            os.remove(BOT_PID_FILE)
        
        return True, f"机器人已停止 (PID: {pid})"
    except Exception as e:
        return False, f"停止失败: {e}"


def read_file(filename, default=""):
    """读取文件内容"""
    try:
        with open(filename, 'r', encoding='utf-8') as f:
            return f.read()
    except FileNotFoundError:
        return default
    except Exception as e:
        return f"读取失败: {e}"


def write_file(filename, content):
    """写入文件"""
    try:
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(content)
        return True, "保存成功"
    except Exception as e:
        return False, f"保存失败: {e}"


def read_logs(max_lines=100):
    """读取最新的日志"""
    try:
        if not os.path.exists(BOT_LOG_FILE):
            return "暂无日志文件\n\n💡 提示：\n1. 点击侧边栏的 '启动' 按钮启动机器人\n2. 等待 2-3 秒后点击 '刷新' 按钮\n3. 如果仍无日志，检查 main.py 是否有错误"
        
        # 检查文件大小
        file_size = os.path.getsize(BOT_LOG_FILE)
        if file_size == 0:
            return "日志文件为空\n\n💡 提示：\n1. 机器人可能刚启动，请等待 2-3 秒\n2. 点击 '刷新' 按钮查看最新日志\n3. 如果持续为空，可能 main.py 启动失败"
        
        with open(BOT_LOG_FILE, 'r', encoding='utf-8', errors='ignore') as f:
            lines = f.readlines()
            if not lines:
                return "日志文件为空（未写入内容）"
            return ''.join(lines[-max_lines:])
    except Exception as e:
        return f"读取日志失败: {e}"


# ==================== Telethon 异步函数 ====================

async def get_telegram_folders():
    """获取 Telegram 聊天分组"""
    try:
        TELEGRAM_API_ID = os.getenv('TELEGRAM_API_ID')
        TELEGRAM_API_HASH = os.getenv('TELEGRAM_API_HASH')
        
        if not all([TELEGRAM_API_ID, TELEGRAM_API_HASH]):
            return None, "缺少 Telegram API 配置"
        
        # 使用独立的 admin session，避免与 main.py 冲突
        # 如果 admin session 不存在，复制 userbot_session
        admin_session = 'admin_session'
        if not os.path.exists(f'{admin_session}.session') and os.path.exists('userbot_session.session'):
            import shutil
            shutil.copy('userbot_session.session', f'{admin_session}.session')
        
        client = TelegramClient(admin_session, int(TELEGRAM_API_ID), TELEGRAM_API_HASH)
        
        # 添加连接超时
        await asyncio.wait_for(client.connect(), timeout=10)
        
        if not await client.is_user_authorized():
            await client.disconnect()
            return None, "未登录 Telegram，请先停止机器人，然后运行 main.py 登录"
        
        result = await client(GetDialogFiltersRequest())
        folders = []
        
        for folder in result:
            if isinstance(folder, DialogFilter):
                folders.append({
                    'id': folder.id,
                    'title': folder.title,
                    'folder': folder
                })
        
        await client.disconnect()
        return folders, "成功"
    except asyncio.TimeoutError:
        return None, "连接超时，请检查网络或重试"
    except Exception as e:
        error_msg = str(e)
        if 'database is locked' in error_msg:
            return None, "数据库被锁定，请先停止机器人后再使用群发功能"
        return None, f"获取分组失败: {e}"


async def get_chats_in_folder(folder):
    """获取分组中的对话"""
    try:
        TELEGRAM_API_ID = os.getenv('TELEGRAM_API_ID')
        TELEGRAM_API_HASH = os.getenv('TELEGRAM_API_HASH')
        
        # 使用独立的 admin session
        client = TelegramClient('admin_session', int(TELEGRAM_API_ID), TELEGRAM_API_HASH)
        await asyncio.wait_for(client.connect(), timeout=10)
        
        chats = []
        all_dialogs = await client.get_dialogs()
        
        # 收集分组中的 peer IDs
        included_peer_ids = set()
        
        if hasattr(folder, 'pinned_peers') and folder.pinned_peers:
            for peer in folder.pinned_peers:
                try:
                    entity = await client.get_entity(peer)
                    included_peer_ids.add(entity.id)
                except:
                    pass
        
        if hasattr(folder, 'include_peers') and folder.include_peers:
            for peer in folder.include_peers:
                try:
                    entity = await client.get_entity(peer)
                    included_peer_ids.add(entity.id)
                except:
                    pass
        
        for dialog in all_dialogs:
            if dialog.entity.id in included_peer_ids:
                chats.append(dialog)
        
        await client.disconnect()
        return chats, "成功"
    except asyncio.TimeoutError:
        return None, "连接超时"
    except Exception as e:
        error_msg = str(e)
        if 'database is locked' in error_msg:
            return None, "数据库被锁定，请先停止机器人"
        return None, f"获取对话失败: {e}"


async def send_broadcast_async(chats, message, progress_callback):
    """异步执行群发"""
    TELEGRAM_API_ID = os.getenv('TELEGRAM_API_ID')
    TELEGRAM_API_HASH = os.getenv('TELEGRAM_API_HASH')
    
    # 使用独立的 admin session
    client = TelegramClient('admin_session', int(TELEGRAM_API_ID), TELEGRAM_API_HASH)
    await asyncio.wait_for(client.connect(), timeout=10)
    
    total = len(chats)
    success = 0
    failed = 0
    
    for idx, dialog in enumerate(chats):
        try:
            # 获取名称
            if hasattr(dialog.entity, 'title'):
                name = dialog.entity.title
            elif hasattr(dialog.entity, 'first_name'):
                name = dialog.entity.first_name
            else:
                name = "Unknown"
            
            progress_callback(idx + 1, total, f"正在发送给: {name}")
            
            await client.send_message(dialog.entity, message)
            success += 1
            
            # 随机延迟 5-10 秒
            if idx < total - 1:
                delay = random.uniform(5, 10)
                await asyncio.sleep(delay)
        
        except FloodWaitError as e:
            progress_callback(idx + 1, total, f"触发限流，等待 {e.seconds} 秒...")
            await asyncio.sleep(e.seconds)
            failed += 1
        
        except PeerFloodError:
            progress_callback(idx + 1, total, "检测到 PeerFlood，停止发送")
            failed += total - idx
            break
        
        except Exception as e:
            progress_callback(idx + 1, total, f"发送失败: {e}")
            failed += 1
    
    await client.disconnect()
    return success, failed


# ==================== 主界面 ====================

def main():
    # 标题
    st.markdown('<div class="main-header">🤖 Telegram AI 中控台</div>', unsafe_allow_html=True)
    
    # ==================== 侧边栏 ====================
    with st.sidebar:
        st.title("⚙️ 控制面板")
        
        # 状态显示
        is_running, pid = get_bot_status()
        if is_running:
            st.markdown(f'<div class="status-running">🟢 运行中 (PID: {pid})</div>', unsafe_allow_html=True)
        else:
            st.markdown('<div class="status-stopped">🔴 已停止</div>', unsafe_allow_html=True)
        
        st.divider()
        
        # 控制按钮
        col1, col2 = st.columns(2)
        
        with col1:
            if st.button("🚀 启动", use_container_width=True, type="primary", disabled=is_running):
                success, message = start_bot()
                if success:
                    st.success(message)
                    time.sleep(1)
                    st.rerun()
                else:
                    st.error(message)
        
        with col2:
            if st.button("⛔ 停止", use_container_width=True, type="secondary", disabled=not is_running):
                success, message = stop_bot()
                if success:
                    st.success(message)
                    time.sleep(1)
                    st.rerun()
                else:
                    st.error(message)
        
        st.divider()
        
        # 系统信息
        st.subheader("📊 系统信息")
        st.text(f"项目路径: {os.getcwd()}")
        st.text(f"Python: {sys.version.split()[0]}")
        
        if os.path.exists(".env"):
            st.success("✅ .env 配置完成")
        else:
            st.error("❌ 缺少 .env 文件")
        
        if os.path.exists("userbot_session.session"):
            st.success("✅ Telegram 已登录")
        else:
            st.warning("⚠️ 未登录 Telegram")
    
    # ==================== 主界面 Tab ====================
    tab1, tab2, tab3 = st.tabs(["🧠 话术配置", "📢 消息群发", "📜 运行日志"])
    
    # ==================== Tab 1: 话术配置 ====================
    with tab1:
        st.header("🧠 话术配置")
        st.caption("实时生效，无需重启机器人")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.subheader("🎭 AI 人设 (Prompt)")
            prompt_content = read_file("prompt.txt", "你是一个幽默、专业的个人助理。")
            new_prompt = st.text_area(
                "编辑 AI 人设",
                value=prompt_content,
                height=300,
                help="定义 AI 的性格和回复风格"
            )
            
            if st.button("💾 保存人设", use_container_width=True):
                success, message = write_file("prompt.txt", new_prompt)
                if success:
                    st.success("✅ " + message)
                else:
                    st.error("❌ " + message)
        
        with col2:
            st.subheader("🔑 触发关键词 (Keywords)")
            keywords_content = read_file("keywords.txt", "帮我\n求助\nAI")
            new_keywords = st.text_area(
                "编辑触发关键词",
                value=keywords_content,
                height=300,
                help="每行一个关键词，用于群聊触发"
            )
            
            if st.button("💾 保存关键词", use_container_width=True):
                success, message = write_file("keywords.txt", new_keywords)
                if success:
                    st.success("✅ " + message)
                else:
                    st.error("❌ " + message)
        
        st.divider()
        
        # ==================== 功能开关配置 ====================
        st.subheader("⚙️ 功能开关")
        
        # 读取当前配置
        config_content = read_file("config.txt", """# 个人消息回复开关
PRIVATE_REPLY=on

# 群消息回复开关
GROUP_REPLY=on""")
        
        # 解析配置
        current_config = {'PRIVATE_REPLY': True, 'GROUP_REPLY': True}
        for line in config_content.split('\n'):
            if '=' in line and not line.strip().startswith('#'):
                key, value = line.split('=', 1)
                key = key.strip()
                value = value.strip().lower()
                if key in current_config:
                    current_config[key] = (value == 'on')
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("**私聊消息回复**")
            private_reply = st.toggle(
                "开启私聊自动回复",
                value=current_config['PRIVATE_REPLY'],
                help="开启后，所有私聊消息都会自动回复"
            )
            if current_config['PRIVATE_REPLY']:
                st.success("✅ 当前状态：开启")
            else:
                st.error("🔴 当前状态：关闭")
        
        with col2:
            st.markdown("**群聊消息回复**")
            group_reply = st.toggle(
                "开启群聊自动回复",
                value=current_config['GROUP_REPLY'],
                help="开启后，根据关键词和@触发回复"
            )
            if current_config['GROUP_REPLY']:
                st.success("✅ 当前状态：开启")
            else:
                st.error("🔴 当前状态：关闭")
        
        # 保存开关配置
        if st.button("💾 保存开关设置", use_container_width=True, type="primary"):
            new_config = f"""# ========================================
# Telegram AI Bot - 功能开关配置
# ========================================
# 
# 说明：修改后立即生效，无需重启机器人
# 配置值：on 或 off（不区分大小写）
# ========================================

# 个人消息回复开关
# on = 开启（自动回复所有私聊消息）
# off = 关闭（不回复私聊消息）
PRIVATE_REPLY={'on' if private_reply else 'off'}

# 群消息回复开关
# on = 开启（根据关键词和@触发回复）
# off = 关闭（不回复群聊消息）
GROUP_REPLY={'on' if group_reply else 'off'}

# ========================================
# 其他配置（预留）
# ========================================

# 是否显示"正在输入"状态
# SHOW_TYPING=on

# 是否记录聊天日志
# LOG_MESSAGES=on
"""
            success, message = write_file("config.txt", new_config)
            if success:
                st.success("✅ " + message + " - 立即生效！")
            else:
                st.error("❌ " + message)
        
        st.divider()
        st.info("💡 提示：修改后立即生效，机器人会在下一条消息时使用新配置")
    
    # ==================== Tab 2: 消息群发 ====================
    with tab2:
        st.header("📢 消息群发")
        st.warning("⚠️ 频繁群发可能导致账号被限制，建议小批量测试（3-5条）")
        
        # 检查机器人运行状态
        is_bot_running, _ = get_bot_status()
        if is_bot_running:
            st.info("💡 提示：机器人正在运行中。如遇到数据库锁定错误，请先停止机器人再使用群发功能。")
        
        # 初始化 session state
        if 'folders' not in st.session_state:
            st.session_state.folders = None
        if 'selected_folder' not in st.session_state:
            st.session_state.selected_folder = None
        if 'chats' not in st.session_state:
            st.session_state.chats = None
        
        # 步骤 1: 加载分组
        col1, col2 = st.columns([3, 1])
        with col1:
            st.subheader("1️⃣ 选择目标分组")
        with col2:
            if st.button("🔄 加载分组", use_container_width=True):
                with st.spinner("正在连接 Telegram..."):
                    try:
                        # 在新的事件循环中运行
                        loop = asyncio.new_event_loop()
                        asyncio.set_event_loop(loop)
                        folders, message = loop.run_until_complete(get_telegram_folders())
                        loop.close()
                        
                        if folders:
                            st.session_state.folders = folders
                            st.success(f"✅ 加载成功，找到 {len(folders)} 个分组")
                        else:
                            st.error(f"❌ {message}")
                    except Exception as e:
                        st.error(f"❌ 加载失败: {e}")
        
        # 显示分组选择
        if st.session_state.folders:
            folder_names = [f"{f['title']}" for f in st.session_state.folders]
            selected_name = st.selectbox("选择分组", folder_names)
            
            if selected_name:
                selected_idx = folder_names.index(selected_name)
                st.session_state.selected_folder = st.session_state.folders[selected_idx]
                
                # 加载分组中的对话
                if st.button("📋 预览对话列表", use_container_width=True):
                    with st.spinner("正在加载对话..."):
                        try:
                            loop = asyncio.new_event_loop()
                            asyncio.set_event_loop(loop)
                            chats, message = loop.run_until_complete(
                                get_chats_in_folder(st.session_state.selected_folder['folder'])
                            )
                            loop.close()
                            
                            if chats:
                                st.session_state.chats = chats
                                st.success(f"✅ 找到 {len(chats)} 个对话")
                                
                                # 显示前几个
                                with st.expander("查看目标列表"):
                                    for i, dialog in enumerate(chats[:10], 1):
                                        if hasattr(dialog.entity, 'title'):
                                            name = dialog.entity.title
                                        elif hasattr(dialog.entity, 'first_name'):
                                            name = dialog.entity.first_name
                                        else:
                                            name = "Unknown"
                                        st.text(f"{i}. {name}")
                                    
                                    if len(chats) > 10:
                                        st.text(f"... 还有 {len(chats) - 10} 个")
                            else:
                                st.error(f"❌ {message}")
                        except Exception as e:
                            st.error(f"❌ 加载失败: {e}")
        
        st.divider()
        
        # 步骤 2: 输入消息
        st.subheader("2️⃣ 输入消息内容")
        message_content = st.text_area(
            "消息内容",
            placeholder="输入要群发的消息...",
            height=150
        )
        
        st.divider()
        
        # 步骤 3: 开始群发
        st.subheader("3️⃣ 开始群发")
        
        if not st.session_state.chats:
            st.info("请先加载分组和对话列表")
        elif not message_content.strip():
            st.info("请输入消息内容")
        else:
            col1, col2 = st.columns([3, 1])
            with col1:
                st.text(f"准备发送到 {len(st.session_state.chats)} 个对话")
            with col2:
                if st.button("🚀 开始群发", type="primary", use_container_width=True):
                    progress_bar = st.progress(0)
                    status_text = st.empty()
                    
                    def update_progress(current, total, message):
                        progress = current / total
                        progress_bar.progress(progress)
                        status_text.text(f"[{current}/{total}] {message}")
                    
                    try:
                        loop = asyncio.new_event_loop()
                        asyncio.set_event_loop(loop)
                        success, failed = loop.run_until_complete(
                            send_broadcast_async(
                                st.session_state.chats,
                                message_content,
                                update_progress
                            )
                        )
                        loop.close()
                        
                        # 显示结果
                        st.success(f"✅ 群发完成！成功: {success}, 失败: {failed}")
                    except Exception as e:
                        st.error(f"❌ 群发失败: {e}")
    
    # ==================== Tab 3: 运行日志 ====================
    with tab3:
        st.header("📜 运行日志")
        
        col1, col2, col3 = st.columns([5, 1, 1])
        with col1:
            st.caption("实时显示机器人运行日志")
        with col2:
            # 自动刷新选项
            auto_refresh = st.checkbox("自动刷新", value=False)
        with col3:
            if st.button("🔄 刷新", use_container_width=True):
                st.rerun()
        
        # 显示日志文件信息
        if os.path.exists(BOT_LOG_FILE):
            file_size = os.path.getsize(BOT_LOG_FILE)
            st.caption(f"日志文件大小: {file_size} 字节 | 最后修改: {datetime.fromtimestamp(os.path.getmtime(BOT_LOG_FILE)).strftime('%H:%M:%S')}")
        
        logs = read_logs(100)
        st.text_area("日志内容", value=logs, height=450, disabled=True)
        
        col1, col2 = st.columns([5, 1])
        with col2:
            if st.button("🗑️ 清空日志", use_container_width=True):
                try:
                    open(BOT_LOG_FILE, 'w').close()
                    st.success("✅ 日志已清空")
                    time.sleep(0.5)
                    st.rerun()
                except Exception as e:
                    st.error(f"❌ 清空失败: {e}")
        
        # 自动刷新功能
        if auto_refresh:
            time.sleep(2)
            st.rerun()


if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        st.error(f"❌ 程序错误: {e}")
        import traceback
        st.code(traceback.format_exc())


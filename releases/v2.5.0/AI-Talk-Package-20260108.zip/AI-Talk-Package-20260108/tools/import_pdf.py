import os
import sys
import PyPDF2

def import_pdf(pdf_path, output_path):
    if not os.path.exists(pdf_path):
        print(f"❌ PDF file not found: {pdf_path}")
        return False

    print(f"📂 Reading PDF: {pdf_path}")
    
    try:
        text_content = []
        with open(pdf_path, 'rb') as f:
            reader = PyPDF2.PdfReader(f)
            num_pages = len(reader.pages)
            print(f"📄 Found {num_pages} pages.")
            
            for i in range(num_pages):
                page = reader.pages[i]
                text = page.extract_text()
                if text:
                    # Add a header for each page to work with _parse_markdown_kb
                    text_content.append(f"# PDF Page {i+1}\n{text}\n")
        
        full_text = "\n".join(text_content)
        
        # Write to extra_kb.txt
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(full_text)
            
        print(f"✅ Successfully extracted text to: {output_path}")
        return True
        
    except Exception as e:
        print(f"❌ Error processing PDF: {e}")
        return False

if __name__ == "__main__":
    # Default paths
    pdf_path = r"d:\下载\api文档.pdf"
    
    # Locate the project root relative to this script
    script_dir = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.dirname(script_dir)
    output_path = os.path.join(project_root, "platforms", "telegram", "extra_kb.txt")
    
    if len(sys.argv) > 1:
        pdf_path = sys.argv[1]
        
    success = import_pdf(pdf_path, output_path)
    
    if success:
        # Update config to trigger refresh
        config_path = os.path.join(project_root, "platforms", "telegram", "config.txt")
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                lines = f.readlines()
            
            new_lines = []
            kb_refresh_found = False
            for line in lines:
                if line.strip().startswith("KB_REFRESH="):
                    new_lines.append("KB_REFRESH=on\n")
                    kb_refresh_found = True
                else:
                    new_lines.append(line)
            
            if not kb_refresh_found:
                new_lines.append("KB_REFRESH=on\n")
                
            with open(config_path, 'w', encoding='utf-8') as f:
                f.writelines(new_lines)
            
            print("🔄 Updated config.txt: KB_REFRESH=on")
            print("🚀 Please restart the bot to apply changes.")
            
        except Exception as e:
            print(f"⚠️ Failed to update config: {e}")

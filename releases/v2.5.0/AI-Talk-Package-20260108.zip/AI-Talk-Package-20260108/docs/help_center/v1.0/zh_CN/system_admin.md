# 系统管理 (System Admin)

> **Version**: 1.1  
> **Last Updated**: 2026-01-07


系统管理模块负责环境配置、会话管理及安全设置。

## 🕹️ 功能操作指南

### 1. 会话与安全 (Session & Security)
**面包屑**: `系统配置自动化` > `环境与会话` Tab

管理 Telegram 会话文件及二次验证。

- **操作按钮**: `生成二次验证码`
  - **点击效果**: 基于当前密钥生成 TOTP 验证码，用于登录验证。
  - **使用场景**: 当 Telegram 登录需要 2FA 时使用。
- **操作按钮**: `查看明文`
  - **点击效果**: 临时显示隐藏的敏感信息（如 API Key）。
  - **安全提示**: 请确保周围无他人窥视。

### 2. 环境初始化 (Initialization)
**面包屑**: `系统配置自动化` > `环境与会话` Tab

- **操作按钮**: `一键生成环境配置`
  - **点击效果**: 创建默认的 `.env` 文件。
- **操作按钮**: `初始化 Session`
  - **点击效果**: 尝试连接 Telegram 服务器并生成会话文件。

### 2.1 服务控制 (Start / Stop / Restart)
**面包屑**: `Telegram 面板` 顶部控制区

- **启动 (Start Bot)**  
  - 点击后显示进度指示（Spinner），成功后展示 PID 与提示信息，并自动刷新页面。
- **停止 (Stop Bot)**  
  - 点击后显示进度指示，成功后清理 PID 文件并自动刷新页面。
- **重启 (Restart Bot)**  
  - 若机器人正在运行：先停止，短暂等待，再启动；统一显示“正在重启机器人…”进度。  
  - 若机器人未运行：直接执行启动流程，避免按钮禁用导致的操作阻塞。
  - 成功后短暂提示并自动刷新，失败时展示详细错误原因。

### 3. 业务指标监控 (Business Metrics)
**面包屑**: `业务指标` Tab

提供实时的 Token 消耗、成本统计及活跃用户数据。

- **核心指标卡片**:
  - `Active Users (Today)`: 今日活跃用户数（基于去重 Chat ID）。
  - `Total Tokens`: 累计消耗 Token 总量（包含 Input/Output）。
  - `Total Cost`: 累计估算成本（美元）。
  - `Est. Revenue`: 预估营收（模拟数据，可对接支付系统）。

- **可视化图表**:
  - **Message Trend (Line Chart)**: 每日消息量趋势，帮助识别流量高峰。
  - **Cost by Stage (Bar Chart)**: 按对话阶段（Stage）分组的成本分布。
    - *用途*: 分析哪个阶段（如 S3-Proposal）消耗了最多的 AI 算力，以便针对性优化 Prompt。
    - *数据来源*: `message_events` 表中的 `stage` 与 `cost` 字段；前端通过 `pd.DataFrame(cost_by_stage.items(), columns=['Stage','Cost'])` 构建图表数据。

- **常见问题**:
  - *Q: 成本是如何计算的？*
    - A: 系统基于 OpenAI API 返回的 `usage` 字段，结合预设的费率（目前固定为 $0.002/1k tokens，可在代码中配置）自动计算。
  - *Q: 为什么 Active Users 与消息总数不一致？*
    - A: Active Users 是去重后的用户数，而消息总数包含同一用户的多条交互。

# 系统运作状态面板 (System Status Dashboard)

Version: 1.0  
Last Updated: 2026-01-07

## 1. 功能用途
以状态灯展示系统关键节点运行状态，快速判断整体健康水平并支持 drill-down 查看失败样本与处理建议。

## 2. 面板入口与权限
- 菜单：System Status / 系统状态  
- 角色：Admin/Auditor/Operator/TenantAdmin 均可访问；Admin 可查看全局

## 3. 展示结构

### 3.1 总览区
- Overall Status：Healthy/Degraded/Outage  
- 指标：消息吞吐（msg/min）、平均延迟（ms）、失败 Top3 节点  
- 时间窗口：5min/15min/1h，可手动刷新

### 3.2 状态灯矩阵
- 节点与事件映射：  
  - Ingress → MSG_RECEIVED  
  - State Load → STATE_LOADED  
  - Supervisor → SUPERVISOR_DECIDED  
  - KB → KB_RETRIEVED (AI分支生效)
  - Stage Agent → STAGE_AGENT_GENERATED (AI分支生效)
  - Style Guard → STYLE_GUARD (AI分支生效)
  - Audit → AUDIT_RESULT (AI分支生效)
  - Reply → REPLY_SENT  
  - State Update → STATE_UPDATED
- 分支说明：
  - 若命中 QA (QA_HIT)，则自动忽略 KB/Stage/Style/Audit 节点，不计入失败统计。
  - 只有 AI 生成回复的对话才会对中间生成与审核节点进行健康度判定。
- 灯信息：状态、成功率、错误数、p95 延迟

### 3.3 详情抽屉
- 最近失败记录（trace_id 与原因）  
- 跳转日志/导出 trace（可选）

## 4. 判定规则
- Green：error_rate < 1% 且 p95_latency < 阈值  
- Yellow：1% ≤ error_rate < 5% 或 p95_latency 超阈值  
- Red：error_rate ≥ 5%  
- Gray：无数据

## 5. 数据来源
- 读取 `platforms/telegram/logs/trace.jsonl` 的结构化事件（JSONL）  
- 每轮对话以统一 `trace_id` 贯穿

## 6. 常见问题 (FAQ)

- Q: 灯为 Gray？  
  A: 当前窗口无事件或通道未启用。
- Q: KB 灯为 Red？  
  A: 知识库为空或 Stage 过滤不一致，检查标签与 DB。
- Q: AI Provider 为 Red？  
  A: Base URL 不可达或服务异常，检查网络与配置。

# 🤖 AI Talk - 企业级智能客服与营销系统

<div align="center">

[![Python](https://img.shields.io/badge/Python-3.10+-blue.svg)](https://www.python.org/)
[![Telethon](https://img.shields.io/badge/Telethon-1.34.0-green.svg)](https://github.com/LonamiWebs/Telethon)
[![Streamlit](https://img.shields.io/badge/Streamlit-1.30.0+-red.svg)](https://streamlit.io/)
[![License](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

**不仅是聊天机器人，更是您的 7x24 小时超级员工**

[快速开始](#-快速开始) | [核心特性](#-核心特性) | [系统架构](#-系统架构) | [完整文档](docs/help_center/v1.0/zh_CN/index.md)

</div>

---

## 📖 项目简介

**AI Talk** 是一套基于 **LLM (大语言模型)** + **RAG (检索增强生成)** + **Multi-Agent (多智能体协作)** 架构的智能客服与营销系统。

不同于简单的“关键词回复”或“纯 GPT 聊天”，本系统引入了**SOP 标准作业程序**和**双重风控审计**，能够像真人一样处理复杂的业务流程（如：售后咨询、规则解答、入金引导），并确保输出内容的安全合规。

![系统全景图](docs/images/11-Telegram系统功能全景.png)

---

## ✨ 核心特性

### 🧠 智能体协作网络 (Agentic Workflow)
*   **Router Agent (路由)**：精准识别用户意图（闲聊/咨询/投诉/转人工），自动分发给对应的专员。
*   **Supervisor Agent (主管)**：基于 SOP 状态机管理多轮对话流程，确保业务不跑偏，主动推动转化。
*   **Worker Agents (专员)**：不同人设的执行者（如“严谨的技术支持”、“热情的销售顾问”），结合 RAG 知识库提供专业回答。

### 🛡️ 企业级风控与审计
*   **双重审计机制**：
    *   **L1 本地风控**：基于关键词和正则的毫秒级拦截。
    *   **L2 AI 审计**：由 Auditor Agent 对回复内容进行语义审查，杜绝虚假承诺和敏感言论。
*   **人工接管 (Handoff)**：支持一键切换至人工模式，无缝衔接复杂客诉。

### 📚 动态知识库 (RAG)
*   **多格式支持**：直接上传 PDF/Word/Excel/TXT，系统自动清洗、切片并向量化。
*   **实时更新**：后台添加知识点后立即生效，无需重新训练模型。
*   **混合检索**：结合关键词匹配与语义搜索，大幅提升回答准确率。

### 🔌 全渠道接入
*   **Telegram**：深度集成，支持私聊、群聊（白名单/黑名单）、频道管理。
*   **WhatsApp**：支持 Web 协议自动化接入（Beta）。

### 💻 现代化管理后台
*   **可视化配置**：所见即所得地编辑 AI 人设、SOP 流程和风控规则。
*   **数据看板**：实时监控对话质量、Token 消耗和用户活跃度。
*   **一键群发**：基于分组的智能群发工具，内置防封禁策略。

---

## 🏗️ 系统架构

本系统采用分层智能架构，确保从“理解”到“执行”再到“风控”的完整闭环。

![业务时序图](docs/images/10-客户到AI完整时序.png)

| 层级 | 模块 | 职责 |
| :--- | :--- | :--- |
| **L0** | **Base AI** | 提供底层的语义理解与生成能力 (DeepSeek/GPT-4)。 |
| **L1** | **Worker Agents** | 结合知识库执行具体任务 (QA 问答、报价计算)。 |
| **L2** | **Manager Agents** | 负责任务分发 (Router)、流程控制 (Supervisor) 与 质量审计 (Auditor)。 |

---

## 🚀 快速开始

### 环境要求
*   Python 3.10+
*   Redis (可选，用于高性能缓存)
*   PostgreSQL (可选，生产环境推荐)

### 1. 安装项目

```bash
# 克隆仓库
git clone https://github.com/hverlott/AI----agent.git
cd AI-Talk

# 安装依赖
pip install -r requirements.txt
```

### 2. 配置环境

复制 `.env.example` 为 `.env` 并填入必要的 API Key：

```ini
# Telegram 配置
TELEGRAM_API_ID=123456
TELEGRAM_API_HASH=abcdef...

# AI 模型配置
AI_API_KEY=sk-xxxxxx
AI_BASE_URL=https://api.deepseek.com
AI_MODEL_NAME=deepseek-chat
```

### 3. 启动系统

**Windows 一键启动：**
```cmd
start_admin.bat
```

**Linux/Mac 启动：**
```bash
chmod +x start_admin.sh
./start_admin.sh
```

启动后访问管理后台：`http://localhost:8501`

---

## 📂 文档中心

详细的使用指南和技术说明请参考 [docs/help_center](docs/help_center/v1.0/zh_CN/index.md)：

*   [📘 产品需求文档 (PRD)](docs/help_center/v1.0/zh_CN/Product_Requirements_Document.md)
*   [📕 技术白皮书](docs/help_center/v1.0/zh_CN/Telegram_AI_Bot_Technical_Whitepaper.md)
*   [📙 客服系统说明](docs/help_center/v1.0/zh_CN/客服AI系统说明文档.md)

---

## 🤝 贡献与支持

欢迎提交 Issue 或 Pull Request 来改进本项目。

*   **License**: MIT License
*   **联系作者**: [GitHub Issues](https://github.com/hverlott/AI----agent/issues)

---
<div align="center">
Made with ❤️ by AI Talk Team
</div>

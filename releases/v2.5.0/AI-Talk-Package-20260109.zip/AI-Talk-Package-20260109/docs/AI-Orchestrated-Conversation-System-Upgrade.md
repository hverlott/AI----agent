# AI Orchestrated Conversation System - Upgrade Guide & Release Notes

> **Current Version**: 2.0.0  
> **Last Updated**: 2026-01-07  
> **Status**: Production Ready (Stable)

本文档详细说明了从单轮对话系统 (v1.0) 升级至多阶段编排系统 (v2.0) 的完整流程、变更详情及应急方案。

---

## 1. 版本变更记录 (Changelog)

### v2.0.0 - The "Orchestration" Update (2026-01-07)
**核心变更**: 引入 Supervisor Agent 与状态机，实现长链路销售导向对话。

- **🌟 新增功能**:
    - **Supervisor Agent**: 全局决策中枢，接管路由分发与状态流转。
    - **Stage & Persona**: 基于有限状态机 (FSM) 的多阶段、多人设管理。
    - **Business Metrics**: 实时 Token 消耗、成本统计及 Stage 成本分布分析。
    - **Exception Handling**: 增强的 Supervisor 异常捕获与自动兜底 (Fallback) 机制。
    - **Admin Dashboard**: 全新的 Streamlit 管理后台，集成编排、监控与客服功能。

- **🔧 架构调整**:
    - 数据库架构升级：`message_events` 表新增 `model`, `cost`, `stage` 字段。
    - 引入 `DatabaseManager` 处理自动 Schema 迁移。
    - 废弃硬编码的关键词回复逻辑，转为 Supervisor 动态决策（保留关键词作为辅助）。

- **🐛 修复**:
    - 修复了多轮对话中上下文丢失的问题。
    - 解决了高并发下 SQLite 锁库问题（引入重试机制）。

---

## 2. 升级步骤 (Upgrade Guide)

### 前置条件
- Python 3.8+ 环境
- OpenAI API Key (支持 GPT-4 或兼容模型)
- 现有 v1.0 数据库文件 (`ai_talk.db`) 建议备份

### 步骤一：数据备份 (强烈建议)
在执行任何代码更新前，请手动备份 SQLite 数据库文件。
```bash
cp ai_talk.db ai_talk.db.bak.v1.0
```

### 步骤二：代码更新与依赖安装
拉取最新代码并安装新增依赖（主要是 Streamlit 与 Pandas）。
```bash
git pull origin main
pip install -r requirements.txt
# 确保包含: streamlit, pandas, plotly
```

### 步骤三：数据库迁移 (自动)
v2.0 引入了自动迁移机制。只需启动任意服务组件，系统会自动检测并更新 Schema。
```bash
# 运行 Streamlit Admin 面板触发迁移
streamlit run admin_multi.py
```
*观察控制台日志，确认出现 `Migrating table message_events...` 字样。*

### 步骤四：配置更新
检查 `.env` 文件，确保包含以下新配置项（如有）：
```ini
# 新增（可选，默认使用代码内置值）
SYSTEM_STAGE_TIMEOUT=300
SUPERVISOR_MODEL=gpt-4
```

---

## 3. 回滚方案 (Rollback Plan)

若升级后出现严重故障（如 Supervisor 持续报错、核心业务中断），请执行以下回滚流程。

### 方案 A：快速代码回滚 (数据兼容)
由于 v2.0 仅**新增**字段而非删除核心字段，v1.0 代码通常可直接运行在 v2.0 数据库上（忽略新字段）。
```bash
git checkout v1.0-tag  # 或回退到之前的 commit hash
# 重启服务
python main.py
```

### 方案 B：完整状态回滚 (数据恢复)
若数据库 Schema 损坏，需恢复备份。
1. 停止所有服务。
2. 恢复数据库：
   ```bash
   mv ai_talk.db ai_talk.db.corrupted
   cp ai_talk.db.bak.v1.0 ai_talk.db
   ```
3. 回退代码并重启。

---

## 4. 应急处理流程 (Emergency Procedures)

### 场景 1：Supervisor Agent 持续失败 (Fallback 触发)
**现象**: 用户收到 *"System is currently experiencing high load..."* 且后台无有效回复。
**处理**:
1. 检查 Admin 面板 > `Business Metrics`，确认 Token 额度及 API 连通性。
2. 查看 `audit_logs` 表（或 Admin 面板日志页），筛选 `supervisor_error`。
3. **临时规避**: 在 `config.py` 或环境变量中关闭 `CONV_ORCHESTRATION` (设置为 False)，系统将降级回 v1.0 的简单回复模式（如支持）。

### 场景 2：数据库锁死 (OperationalError: database is locked)
**现象**: 日志大量报错 Database Locked。
**处理**:
1. 确保没有其他 GUI 工具（如 DB Browser）独占打开 `.db` 文件。
2. 重启 Python 服务进程，释放僵死连接。

---

## 5. 兼容性说明 (Compatibility)

- **数据兼容性**: v1.0 的历史消息记录完全保留。升级后，旧数据的 `stage` 字段将为 `NULL` 或默认值，不影响统计。
- **API 兼容性**: 对外 Webhook 接口保持不变，第三方集成无需修改。

---

## 6. 文档索引 (Documentation Index)

- [系统架构概览 (Architecture)](System-Architecture.md)
- [管理后台手册 (Admin Manual)](help_center/v1.0/zh_CN/system_admin.md)
- [监管面板指南 (Supervisor Guide)](help_center/v1.0/zh_CN/supervisor.md)
- [编排面板指南 (Orchestrator Guide)](help_center/v1.0/zh_CN/orchestrator.md)

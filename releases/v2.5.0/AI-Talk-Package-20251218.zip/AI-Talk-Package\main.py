import asyncio
import os
import sys
import httpx # 必须确保已安装: pip install httpx
from telethon import TelegramClient, events
from openai import AsyncOpenAI
from dotenv import load_dotenv

# --- 1. 基础设置 ---
# 解决 Windows 控制台乱码
if sys.platform == 'win32':
    try:
        import codecs
        sys.stdout.reconfigure(encoding='utf-8')
        sys.stderr.reconfigure(encoding='utf-8')
    except:
        pass

load_dotenv()

# --- 2. 加载配置 & 自动修复错误 ---
TELEGRAM_API_ID = os.getenv('TELEGRAM_API_ID')
TELEGRAM_API_HASH = os.getenv('TELEGRAM_API_HASH')
AI_API_KEY = os.getenv('AI_API_KEY')
AI_BASE_URL = os.getenv('AI_BASE_URL')
AI_MODEL_NAME = os.getenv('AI_MODEL_NAME')

# 🔍【自动修复功能】防止 .env 填错
if AI_BASE_URL:
    # 1. 如果忘了写 https://，自动补上
    if not AI_BASE_URL.startswith("http"):
        AI_BASE_URL = f"https://{AI_BASE_URL}"
    
    # 2. 【关键修复】将错误域名 55.ai 替换为正确的 api.55.ai
    if "://55.ai" in AI_BASE_URL:
        AI_BASE_URL = AI_BASE_URL.replace("://55.ai", "://api.55.ai")
        print("⚠️ 检测到旧域名，已自动修正为 api.55.ai")
    
    # 3. 如果多写了 /chat/completions，自动去掉（OpenAI SDK 会自动拼接）
    if "/chat/completions" in AI_BASE_URL:
        AI_BASE_URL = AI_BASE_URL.replace("/chat/completions", "")
    
    # 4. 确保以 /v1 结尾（根据 API 规范）
    if not AI_BASE_URL.endswith("/v1"):
        AI_BASE_URL = AI_BASE_URL.rstrip("/") + "/v1"

print(f"🔧 AI 接口地址已修正为: {AI_BASE_URL}")

# --- 3. 初始化客户端 (抗干扰模式) ---

# 创建一个忽略证书错误的 HTTP 客户端 (解决 SSL Error)
http_client = httpx.AsyncClient(verify=False)

ai_client = AsyncOpenAI(
    api_key=AI_API_KEY,
    base_url=AI_BASE_URL,
    http_client=http_client # 强制使用这个客户端
)

client = TelegramClient('userbot_session', int(TELEGRAM_API_ID), TELEGRAM_API_HASH)

# 【已移除硬编码】现在提示词从 prompt.txt 文件动态加载
# SYSTEM_PROMPT = """..."""

# --- 4. 核心逻辑 ---

def load_system_prompt():
    """
    热更新功能：从 prompt.txt 读取 AI 提示词
    这样可以在程序运行时随时修改 AI 人设，无需重启
    """
    prompt_file = "prompt.txt"
    default_prompt = "你是一个幽默、专业的个人助理，帮机主回复消息。请用自然、友好的语气回复。"
    
    try:
        with open(prompt_file, 'r', encoding='utf-8') as f:
            content = f.read().strip()
            if content:
                return content
            else:
                return default_prompt
    except FileNotFoundError:
        print(f"⚠️ 未找到 {prompt_file}，使用默认提示词")
        return default_prompt
    except Exception as e:
        print(f"⚠️ 读取 {prompt_file} 失败: {e}，使用默认提示词")
        return default_prompt

def load_keywords():
    """
    热更新功能：从 keywords.txt 读取群聊触发关键词
    每次处理消息时重新读取，实现实时更新
    """
    keywords_file = "keywords.txt"
    keywords = []
    
    try:
        with open(keywords_file, 'r', encoding='utf-8') as f:
            for line in f:
                keyword = line.strip()
                # 忽略空行和注释行（以 # 开头）
                if keyword and not keyword.startswith('#'):
                    keywords.append(keyword)
        return keywords
    except FileNotFoundError:
        # 文件不存在时返回空列表（群聊只能通过 @ 触发）
        return []
    except Exception as e:
        print(f"⚠️ 读取 {keywords_file} 失败: {e}")
        return []

async def get_chat_history(chat_id, limit=8, max_id=0):
    """获取聊天上下文"""
    messages = []
    try:
        async for msg in client.iter_messages(chat_id, limit=limit, max_id=max_id):
            if msg.text:
                role = "assistant" if msg.out else "user"
                messages.append({"role": role, "content": msg.text})
        return messages[::-1]
    except Exception:
        return []

@client.on(events.NewMessage(incoming=True))
async def handler(event):
    # 只处理有文本内容的消息
    if not event.message.text:
        return
    
    msg = event.message.text
    sender = await event.get_sender()
    name = getattr(sender, 'first_name', '朋友')
    
    # 【热更新】实时读取关键词列表
    keywords = load_keywords()
    
    # 【智能触发逻辑】
    should_reply = False
    
    if event.is_private:
        # 私聊：直接回复
        should_reply = True
        print(f"📩 收到私聊 [{name}]: {msg}")
    elif event.is_group:
        # 群聊：需要满足以下任一条件
        if event.mentioned:
            # 条件1：被 @ 了
            should_reply = True
            print(f"📩 群聊被 @ [{name}]: {msg}")
        elif keywords:
            # 条件2：消息包含关键词
            for keyword in keywords:
                if keyword.lower() in msg.lower():
                    should_reply = True
                    print(f"📩 群聊触发关键词 [{keyword}] [{name}]: {msg}")
                    break
    
    # 如果不满足回复条件，直接返回
    if not should_reply:
        return

    async with client.action(event.chat_id, 'typing'):
        # 【热更新】每次处理消息前重新读取提示词
        system_prompt = load_system_prompt()
        
        # 获取历史记录（保持上下文）
        history = await get_chat_history(event.chat_id, max_id=event.id)
        
        # 构造发给 AI 的数据
        messages = [{"role": "system", "content": system_prompt}] + history + [{"role": "user", "content": msg}]

        try:
            print("🤖 AI 正在思考...")
            response = await ai_client.chat.completions.create(
                model=AI_MODEL_NAME,
                messages=messages,
                temperature=0.7,
                max_tokens=500
            )
            reply = response.choices[0].message.content
            
            # 模拟打字延迟
            await asyncio.sleep(min(len(reply) * 0.1, 3))
            
            await event.reply(reply)
            print(f"📤 已回复: {reply}")
            
        except Exception as e:
            print(f"❌ AI 调用失败: {e}")

# --- 5. 启动程序 ---
if __name__ == '__main__':
    print("🚀 程序启动中...")
    client.start()
    client.run_until_disconnected()
# 🔧 数据库锁定问题解决方案

## ❌ 错误信息
```
❌ 获取分组失败: database is locked
```

## 📝 问题原因

这个错误是因为 SQLite 数据库（session 文件）同时被多个进程访问导致的：

1. `main.py` 机器人正在运行，占用了 `userbot_session.session`
2. `admin.py` 管理后台试图同时访问同一个文件
3. SQLite 不允许多个进程同时写入

## ✅ 解决方案（已自动修复）

### 方案 1：使用独立 Session（推荐）✨

**代码已更新！** 现在 `admin.py` 会自动使用独立的 `admin_session.session` 文件，避免与 `main.py` 冲突。

**工作原理：**
```python
# 首次运行时，自动复制 userbot_session.session
admin_session = 'admin_session'
if not os.path.exists(f'{admin_session}.session'):
    shutil.copy('userbot_session.session', f'{admin_session}.session')

# 使用独立 session
client = TelegramClient('admin_session', API_ID, API_HASH)
```

### 方案 2：停止机器人后使用群发

如果仍然遇到锁定问题：

1. 在管理后台侧边栏点击 **"⛔ 停止"** 按钮
2. 等待 2-3 秒确保进程完全停止
3. 然后使用群发功能
4. 群发完成后，再点击 **"🚀 启动"** 按钮

## 🚀 使用流程

### 推荐流程（机器人继续运行）

```
1. 启动管理后台
   streamlit run admin.py

2. 首次使用群发功能时
   → 点击"加载分组"
   → 程序自动创建 admin_session.session
   → ✅ 不会冲突！

3. 正常使用所有功能
   → 机器人继续自动回复
   → 同时可以使用群发功能
```

### 备用流程（如果还是有问题）

```
1. 停止机器人
   → 点击侧边栏"停止"按钮
   → 等待 2-3 秒

2. 使用群发功能
   → 加载分组
   → 选择目标
   → 发送消息

3. 重新启动机器人
   → 点击侧边栏"启动"按钮
```

## 🔍 检查文件

运行后，你的项目目录应该有两个 session 文件：

```
D:\AI Talk\
├── userbot_session.session    # main.py 使用
├── admin_session.session       # admin.py 使用 ✨ 新增
└── ...
```

## 📊 测试步骤

### 测试 1：验证独立 Session

```bash
# 1. 启动机器人
streamlit run admin.py
点击"启动"按钮

# 2. 在同一个管理后台
切换到"消息群发" Tab
点击"加载分组"

# 3. 应该成功！
✅ 加载成功，找到 X 个分组
```

### 测试 2：验证错误提示

```bash
# 如果删除 admin_session.session
del admin_session.session  # Windows
rm admin_session.session   # Linux/Mac

# 再次点击"加载分组"
# 程序会自动复制并创建新的 admin_session.session
```

## 💡 额外提示

### 提示 1：首次登录
如果是全新安装，需要先运行 `main.py` 完成 Telegram 登录：
```bash
python main.py
# 输入手机号和验证码
# 生成 userbot_session.session
```

### 提示 2：Session 同步
两个 session 文件都指向同一个 Telegram 账号，但：
- `userbot_session.session` - 机器人专用
- `admin_session.session` - 管理后台专用
- 互不干扰！

### 提示 3：清理旧文件
如果遇到奇怪的问题，可以删除 `admin_session.session`，程序会自动重新创建：
```bash
# Windows
del admin_session.session

# Linux/Mac
rm admin_session.session
```

## 🔧 手动修复（高级用户）

如果自动修复失败，可以手动复制：

### Windows
```cmd
copy userbot_session.session admin_session.session
```

### Linux/Mac
```bash
cp userbot_session.session admin_session.session
```

## ⚠️ 注意事项

1. **不要删除 userbot_session.session**
   - 这是 main.py 的登录凭证
   - 删除后需要重新登录

2. **admin_session.session 可以安全删除**
   - 程序会自动重新创建
   - 不需要重新登录

3. **两个文件都需要保密**
   - 包含登录凭证
   - 不要分享或上传

## 📝 更新日志

### v1.1.0 (当前版本)
- ✅ 添加独立 admin_session 支持
- ✅ 自动复制 session 文件
- ✅ 添加数据库锁定错误提示
- ✅ 添加连接超时机制
- ✅ 添加机器人运行状态提示

### v1.0.0 (初始版本)
- ❌ 使用共享 session（会导致冲突）

---

## ✅ 问题已解决！

现在你可以：
- ✅ 机器人运行时使用群发功能
- ✅ 不需要频繁停止/启动机器人
- ✅ 避免数据库锁定错误

**享受无缝的管理体验！** 🎉


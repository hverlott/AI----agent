#!/usr/bin/env node
/**
 * 预下载 Chromium 浏览器
 * 解决首次启动卡顿问题
 */

const puppeteer = require('puppeteer');

console.log('╔═══════════════════════════════════════════════════╗');
console.log('║   📥 正在下载 Chromium 浏览器...                 ║');
console.log('╚═══════════════════════════════════════════════════╝');
console.log('');
console.log('⏳ 下载大小约 150-200 MB，请耐心等待...');
console.log('💡 这个过程只需要执行一次\n');

(async () => {
    try {
        console.log('🔄 开始下载...\n');
        
        const browser = await puppeteer.launch({
            headless: true,
            args: ['--no-sandbox', '--disable-setuid-sandbox']
        });
        
        console.log('✅ Chromium 浏览器下载完成！');
        console.log('✅ WhatsApp 机器人现在可以正常启动了\n');
        
        await browser.close();
        
        console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
        console.log('📝 下一步：运行 node bot.js 启动机器人');
        console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');
        
    } catch (error) {
        console.error('❌ 下载失败:', error.message);
        console.error('\n💡 请检查网络连接，或尝试手动下载 Chromium');
        process.exit(1);
    }
})();



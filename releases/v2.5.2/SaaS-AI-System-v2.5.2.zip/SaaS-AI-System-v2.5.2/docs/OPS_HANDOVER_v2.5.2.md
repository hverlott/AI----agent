# v2.5.2 升级操作手册 (Ops Handover Guide)

**目标版本**: v2.5.2
**当前版本**: v2.5.1
**操作人员**: 运维工程师 (DevOps/SRE)
**预计耗时**: 5-10 分钟

---

## 1. 升级包准备

请确保您已获得以下文件：
- 升级包: `SaaS-AI-System-v2.5.2.zip`

## 2. 升级方案选择

根据您的服务器访问权限，选择以下任一方案：

### 方案 A：Web 后台自动升级 (推荐)
*适用场景：拥有系统 SuperAdmin 账号，且服务器允许出网或本地上传。*

1. 登录管理后台 (默认端口 8501)。
2. 导航至 **系统管理** -> **🚀 系统升级与维护**。
3. 在 **“☁️ 在线升级”** 或 **“📦 离线包升级”** 区域操作。
   - 如果服务器可联网 GitHub，直接点击 **“🔍 检查更新”** -> **“⬇️ 下载并安装”**。
   - 如果是内网环境，请使用 **“系统升级”** (旧版入口) 上传 `SaaS-AI-System-v2.5.2.zip`。
4. 系统会自动完成解压、迁移和重启。

---

### 方案 B：服务器端手动升级 (标准流程)
*适用场景：仅有 SSH/RDP 权限，需严格控制变更流程。*

#### 步骤 1: 备份 (Critical)
在执行任何操作前，请备份当前运行目录下的 `data` 文件夹。
```bash
# Linux
cp -r /path/to/project/data /path/to/project/data_backup_v2.5.1

# Windows
xcopy data data_backup_v2.5.1 /E /I
```

#### 步骤 2: 部署新版本代码
将升级包解压到 `releases` 目录下的新版本文件夹中。

假设根目录为 `/app/SaaS-AIs/`，当前运行在 `/app/SaaS-AIs/releases/v2.5.1/`。

1. 创建新目录: `/app/SaaS-AIs/releases/v2.5.2/`
2. 解压 `SaaS-AI-System-v2.5.2.zip` 到该目录。

#### 步骤 3: 数据库迁移
v2.5.2 引入了配置数据库化，**必须**执行迁移脚本。

**Windows:**
```powershell
cd D:\SaaS-AIs\releases\v2.5.2
..\..\.venv\Scripts\activate
python scripts/migrate_to_db.py
```

**Linux:**
```bash
cd /app/SaaS-AIs/releases/v2.5.2
source ../../.venv/bin/activate
python scripts/migrate_to_db.py
```
> **验证**: 脚本应输出 "Migration successful" 或 "Configuration migrated to DB"。

#### 步骤 4: 切换版本
使用内置工具或手动修改启动脚本。

**方式 1 (推荐): 使用版本管理器**
```bash
# 在 v2.5.2 目录下运行
python -c "from version_manager import VersionManager; vm = VersionManager('.'); vm.switch_version('v2.5.2')"
```

**方式 2 (手动): 修改 start.bat / start.sh**
编辑根目录下的 `start.bat`，修改 `LATEST_VERSION` 变量：
```bat
set "LATEST_VERSION=v2.5.2"
```

#### 步骤 5: 重启服务
重启主进程和管理后台。
```bash
# 停止旧进程
# 启动新进程
./start_admin.bat
python main.py
```

---

## 3. 验证清单

1. **版本检查**: 登录后台，底部版本号应显示 `v2.5.2`。
2. **功能检查**:
   - 进入 **Telegram 配置**，确认可以看到 **内容过滤配置** 面板。
   - 进入 **技能中心**，列表加载正常。
3. **日志检查**: 查看 `platforms/telegram/logs/system.log` 无报错。

---

**遇到问题?**
请执行回滚：将 `start.bat` 中的版本改回 `v2.5.1` 并重启即可。

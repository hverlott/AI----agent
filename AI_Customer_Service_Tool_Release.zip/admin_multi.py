#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
多平台社交媒体 AI Bot - 统一管理后台
支持 Telegram, WhatsApp, Facebook, Messenger, 微信等
"""

import streamlit as st
import os
import sys
import json
import re
from datetime import datetime
from admin import render_login_panel
import asyncio

# 页面配置
st.set_page_config(
    page_title="👑鼎盛👑内部工具",
    page_icon="👑",
    layout="wide",
    initial_sidebar_state="expanded"
)

# CSS 样式（优化紧凑版）
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        font-weight: bold;
        text-align: center;
        background: linear-gradient(120deg, #1f77b4, #ff7f0e);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        margin-bottom: 1.5rem;
    }
    .platform-card {
        padding: 1rem;
        border-radius: 8px;
        border: 2px solid #e0e0e0;
        margin: 0.3rem 0;
        transition: all 0.3s;
    }
    .platform-card:hover {
        border-color: #1f77b4;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    .platform-active {
        border-color: #1f77b4 !important;
        background-color: #f0f8ff;
    }
    .status-badge {
        display: inline-block;
        padding: 0.2rem 0.5rem;
        border-radius: 10px;
        font-size: 0.75rem;
        font-weight: bold;
    }
    .status-running {
        background-color: #d4edda;
        color: #155724;
    }
    .status-stopped {
        background-color: #f8d7da;
        color: #721c24;
    }
    .status-pending {
        background-color: #fff3cd;
        color: #856404;
    }
    /* 紧凑侧边栏样式 */
    [data-testid="stSidebar"] {
        padding-top: 2rem;
    }
    [data-testid="stSidebar"] .element-container {
        margin-bottom: 0.3rem;
    }
    [data-testid="stSidebar"] button {
        padding: 0.3rem 0.5rem;
        font-size: 0.85rem;
    }
    [data-testid="stSidebar"] small {
        font-size: 0.85rem;
    }
</style>
""", unsafe_allow_html=True)

# 平台配置
PLATFORMS = {
    'telegram': {
        'name': 'Telegram',
        'icon': '📱',
        'color': '#0088cc',
        'status': 'available',  # available, unavailable, coming_soon
        'description': '全功能支持 - 私聊/群聊/频道'
    },
    'whatsapp': {
        'name': 'WhatsApp',
        'icon': '💬',
        'color': '#25D366',
        'status': 'available',
        'description': '✅ 可用 - 私聊/群聊自动回复'
    },
    'facebook': {
        'name': 'Facebook',
        'icon': '📘',
        'color': '#1877f2',
        'status': 'coming_soon',
        'description': '规划中 - Messenger + 主页'
    },
    'messenger': {
        'name': 'Messenger',
        'icon': '💙',
        'color': '#006aff',
        'status': 'coming_soon',
        'description': '规划中 - 独立客户端'
    },
    'wechat': {
        'name': '微信 WeChat',
        'icon': '💚',
        'color': '#07c160',
        'status': 'coming_soon',
        'description': '规划中 - 个人号/公众号'
    },
    'instagram': {
        'name': 'Instagram',
        'icon': '📷',
        'color': '#E4405F',
        'status': 'coming_soon',
        'description': '规划中 - DM 自动回复'
    },
    'twitter': {
        'name': 'Twitter/X',
        'icon': '🐦',
        'color': '#1DA1F2',
        'status': 'coming_soon',
        'description': '规划中 - DM + 提及回复'
    },
    'discord': {
        'name': 'Discord',
        'icon': '💜',
        'color': '#5865F2',
        'status': 'coming_soon',
        'description': '规划中 - 服务器 Bot'
    }
}

TG_GROUP_CACHE_FILE = "platforms/telegram/group_cache.json"
TG_SELECTED_GROUPS_FILE = "platforms/telegram/selected_groups.json"

def load_platform_config(platform):
    """加载平台配置"""
    config_file = f"platforms/{platform}/config.json"
    try:
        if os.path.exists(config_file):
            with open(config_file, 'r', encoding='utf-8') as f:
                return json.load(f)
    except:
        pass
    return {}

def save_platform_config(platform, config):
    """保存平台配置"""
    config_file = f"platforms/{platform}/config.json"
    os.makedirs(os.path.dirname(config_file), exist_ok=True)
    with open(config_file, 'w', encoding='utf-8') as f:
        json.dump(config, f, indent=2, ensure_ascii=False)


def load_tg_group_cache():
    try:
        with open(TG_GROUP_CACHE_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
            if isinstance(data, dict):
                return data
    except:
        pass
    return {}


def load_tg_selected_groups():
    try:
        with open(TG_SELECTED_GROUPS_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
            return data.get('selected_ids', [])
    except:
        return []


def save_tg_selected_groups(selected_ids):
    os.makedirs(os.path.dirname(TG_SELECTED_GROUPS_FILE), exist_ok=True)
    with open(TG_SELECTED_GROUPS_FILE, 'w', encoding='utf-8') as f:
        json.dump({'selected_ids': selected_ids}, f, ensure_ascii=False, indent=2)


def parse_group_ids(raw_text):
    if not raw_text:
        return []
    entries = re.split(r'[,\s]+', raw_text.strip())
    ids = []
    for token in entries:
        if not token:
            continue
        try:
            ids.append(int(token))
        except:
            continue
    return ids

def render_platform_selector():
    """渲染平台选择器（优化紧凑版）"""
    st.sidebar.markdown("### 🌐 平台")
    
    selected_platform = st.session_state.get('selected_platform', 'telegram')
    
    for platform_id, platform_info in PLATFORMS.items():
        # 创建紧凑的平台选项
        col1, col2, col3 = st.sidebar.columns([1, 3, 1])
        
        with col1:
            st.markdown(f"<div style='font-size: 1.5rem;'>{platform_info['icon']}</div>", 
                      unsafe_allow_html=True)
        
        with col2:
            st.markdown(f"<small>**{platform_info['name']}**</small>", 
                      unsafe_allow_html=True)
        
        with col3:
            # 状态标识（简化版）
            if platform_info['status'] == 'available':
                st.markdown("🟢", unsafe_allow_html=True)
            elif platform_info['status'] == 'coming_soon':
                st.markdown("🟡", unsafe_allow_html=True)
            else:
                st.markdown("🔴", unsafe_allow_html=True)
        
        # 选择按钮（紧凑版）
        button_label = "✓" if selected_platform == platform_id else "选择"
        if st.sidebar.button(
            button_label,
            key=f"select_{platform_id}",
            disabled=(platform_info['status'] != 'available'),
            use_container_width=True,
            type="primary" if selected_platform == platform_id else "secondary"
        ):
            st.session_state.selected_platform = platform_id
            st.rerun()
    
    return selected_platform

def render_telegram_panel():
    """渲染 Telegram 控制面板"""
    from admin import (
        get_bot_status, start_bot, stop_bot, 
        read_file, write_file, read_logs
    )
    
    st.header("📱 Telegram AI Bot 控制面板")
    
    # 状态显示
    col1, col2, col3 = st.columns(3)
    
    with col1:
        is_running, pid = get_bot_status()
        if is_running:
            st.success(f"🟢 运行中 (PID: {pid})")
        else:
            st.error("🔴 已停止")
    
    with col2:
        if os.path.exists("userbot_session.session"):
            st.success("✅ 已登录")
        else:
            st.warning("⚠️ 未登录")
            if st.button("\u672a\u767b\u5f55 Telegram (\u70b9\u51fb\u767b\u5f55)"):
                st.session_state.show_login_panel = True
    
    with col3:
        if os.path.exists(".env"):
            st.success("✅ 已配置")
        else:
            st.error("❌ 未配置")
    
    st.divider()
    with st.expander("Telegram \u767b\u5f55", expanded=st.session_state.get('show_login_panel', False)):
        render_login_panel()
    
    # 控制按钮
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if st.button("🚀 启动机器人", use_container_width=True, type="primary", 
                    disabled=is_running):
            success, message = start_bot()
            if success:
                st.success(message)
                st.rerun()
            else:
                st.error(message)
    
    with col2:
        if st.button("⛔ 停止机器人", use_container_width=True, 
                    disabled=not is_running):
            success, message = stop_bot()
            if success:
                st.success(message)
                st.rerun()
            else:
                st.error(message)
    
    with col3:
        if st.button("🔄 重启机器人", use_container_width=True,
                    disabled=not is_running):
            stop_bot()
            import time
            time.sleep(1)
            start_bot()
            st.success("机器人已重启")
            st.rerun()
    
    st.divider()
    
    # Tab 界面
    tabs = ["🧠 配置", "📢 群发", "📜 日志", "📊 统计"]
    tab_choice = st.radio("功能", tabs, horizontal=True, key='tg_panel_tab')
    if tab_choice == tabs[0]:
        render_telegram_config()
    elif tab_choice == tabs[1]:
        render_telegram_broadcast()
    elif tab_choice == tabs[2]:
        render_telegram_logs()
    else:
        render_telegram_stats()

def render_telegram_config():
    """Telegram 配置界面"""
    from admin import read_file, write_file
    
    st.subheader("⚙️ 配置管理")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("**AI 人设**")
        prompt = st.text_area(
            "编辑提示词",
            value=read_file("prompt.txt"),
            height=200,
            key="tg_prompt"
        )
        if st.button("💾 保存人设", key="save_prompt"):
            write_file("prompt.txt", prompt)
            st.success("✅ 已保存")
    
    with col2:
        st.markdown("**触发关键词**")
        keywords = st.text_area(
            "每行一个",
            value=read_file("keywords.txt", "帮我\n求助\nAI"),
            height=200,
            key="tg_keywords"
        )
        if st.button("💾 保存关键词", key="save_keywords"):
            write_file("keywords.txt", keywords)
            st.success("✅ 已保存")
    
    st.divider()
    
    # 功能开关
    st.markdown("**功能开关**")
    config_content = read_file("platforms/telegram/config.txt", "PRIVATE_REPLY=on\nGROUP_REPLY=on")
    
    current_config = {
        'PRIVATE_REPLY': True,
        'GROUP_REPLY': True,
        'GROUP_CONTEXT': False
    }
    for line in config_content.split('\n'):
        if '=' in line and not line.strip().startswith('#'):
            key, value = line.split('=', 1)
            key = key.strip()
            value = value.strip().lower()
            if key in current_config:
                current_config[key] = (value == 'on')
    
    col1, col2 = st.columns(2)
    
    with col1:
        private_reply = st.toggle(
            "私聊自动回复",
            value=current_config['PRIVATE_REPLY'],
            key="tg_private"
        )
    
    with col2:
        group_reply = st.toggle(
            "群聊自动回复",
            value=current_config['GROUP_REPLY'],
            key="tg_group"
        )
    
    context_reply = st.toggle(
        "群聊上下文自动回复",
        value=current_config['GROUP_CONTEXT'],
        key="tg_context"
    )
    st.caption("开启后即使消息未命中关键词或 @ 也会结合上下文回复，关闭时仍需关键词/@ 触发。")

    if st.button("💾 保存开关", use_container_width=True):
        new_config = (
            f"PRIVATE_REPLY={'on' if private_reply else 'off'}\n"
            f"GROUP_REPLY={'on' if group_reply else 'off'}\n"
            f"GROUP_CONTEXT={'on' if context_reply else 'off'}"
        )
        write_file("platforms/telegram/config.txt", new_config)
        st.success("✅ 已保存")

    st.divider()
    st.markdown("**群聊白名单**")
    st.caption("选择的群聊才能自动回复，留空时默认遵循 GROUP_REPLY 开关对所有群聊有效。")

    selected_group_ids = load_tg_selected_groups()
    group_cache = load_tg_group_cache()
    group_rows = []
    display_map = {}

    if group_cache:
        sorted_cache = sorted(
            group_cache.items(),
            key=lambda kv: (kv[1].get('title') or "").lower()
        )
        for chat_id_str, detail in sorted_cache:
            try:
                chat_id = int(chat_id_str)
            except:
                continue

            title = detail.get('title') or "未命名群聊"
            last_seen = detail.get('last_seen') or "未知"
            group_rows.append({
                "群名称": title,
                "群 ID": chat_id,
                "最近活跃": last_seen
            })
            display_label = f"{title} ({chat_id})"
            display_map[display_label] = chat_id

        if group_rows:
            st.table(group_rows)
    else:
        st.info("机器人尚未缓存任何群聊，先接收群消息后再回来配置白名单。")

    selected_from_list = []
    if display_map:
        default_displays = [
            label for label, gid in display_map.items()
            if gid in selected_group_ids
        ]
        picked = st.multiselect(
            "选中的群聊",
            options=list(display_map.keys()),
            default=default_displays,
            key="tg_group_whitelist"
        )
        selected_from_list = [
            display_map[label] for label in picked if label in display_map
        ]

    known_ids = set(display_map.values())
    manual_unknown = sorted(
        gid for gid in selected_group_ids if gid not in known_ids
    )
    manual_value = "\n".join(str(gid) for gid in manual_unknown)
    manual_input = st.text_area(
        "补充群 ID（未在列表中的群，可在此填写，支持换行或逗号分隔）",
        value=manual_value,
        height=100,
        placeholder="-1001234567890\n-1009876543210"
    )

    if st.button("💾 保存群聊白名单", use_container_width=True):
        manual_ids = parse_group_ids(manual_input)
        combined = sorted(set(selected_from_list + manual_ids))
        save_tg_selected_groups(combined)
        st.success("✅ 群聊白名单已保存，仅选中群聊会自动回复")
        st.rerun()

async def send_broadcast_ids_with_interval(target_ids, id_name_map, message, interval_sec, progress_callback):
    """Telegram broadcast by chat id with configurable interval and records."""
    from telethon import TelegramClient
    from telethon.errors import FloodWaitError, PeerFloodError

    api_id = os.getenv('TELEGRAM_API_ID')
    api_hash = os.getenv('TELEGRAM_API_HASH')
    if not all([api_id, api_hash]):
        return 0, 0, [{"name": "", "id": "", "status": "error", "error": "Missing TELEGRAM_API_ID/TELEGRAM_API_HASH"}]

    client = TelegramClient('admin_session', int(api_id), api_hash)
    await asyncio.wait_for(client.connect(), timeout=10)

    total = len(target_ids)
    success = 0
    failed = 0
    records = []

    for idx, chat_id in enumerate(target_ids):
        name = id_name_map.get(chat_id, "Unknown")
        try:
            progress_callback(idx + 1, total, "\u6b63\u5728\u53d1\u9001: {}".format(name))
            await client.send_message(chat_id, message)
            success += 1
            records.append({"name": name, "id": chat_id, "status": "success", "error": ""})
        except FloodWaitError as e:
            failed += 1
            records.append({"name": name, "id": chat_id, "status": "failed", "error": "FloodWait {}s".format(e.seconds)})
            await asyncio.sleep(e.seconds)
        except PeerFloodError:
            failed += (total - idx)
            records.append({"name": name, "id": chat_id, "status": "failed", "error": "PeerFlood"})
            for rest_id in target_ids[idx + 1:]:
                rest_name = id_name_map.get(rest_id, "Unknown")
                records.append({"name": rest_name, "id": rest_id, "status": "skipped", "error": "PeerFlood"})
            break
        except Exception as e:
            failed += 1
            records.append({"name": name, "id": chat_id, "status": "failed", "error": str(e)})
        if interval_sec and idx < total - 1:
            await asyncio.sleep(interval_sec)

    await client.disconnect()
    return success, failed, records


def render_telegram_broadcast():
    """Telegram \u7fa4\u53d1\u754c\u9762"""
    from admin import get_bot_status

    st.subheader("\U0001F4E2 \u6D88\u606F\u7FA4\u53D1")
    st.warning("\u26a0\uFE0F \u9891\u7E41\u7FA4\u53D1\u53EF\u80FD\u5BFC\u81F4\u8D26\u53F7\u88AB\u9650\u5236\uff0c\u5EFA\u8BAE\u5C0F\u6279\u91CF\u6D4B\u8BD5\uff083-5\u6761\uff09")

    is_bot_running, _ = get_bot_status()
    if is_bot_running:
        st.info("\U0001F4A1 \u63D0\u793A\uff1a\u673A\u5668\u4EBA\u6B63\u5728\u8FD0\u884C\u4E2D。如遇到数据库锁定错误，请先停止机器人再使用群发功能。")

    if 'tg_broadcast_groups' not in st.session_state:
        st.session_state.tg_broadcast_groups = []
    if 'tg_broadcast_records' not in st.session_state:
        st.session_state.tg_broadcast_records = []

    selected_group_ids = set(load_tg_selected_groups())
    filter_mode = st.radio(
        "\u7FA4\u7EC4\u52A0\u8F7D方式",
        ["\u5168\u90E8", "\u4EC5\u767D\u540D\u5355", "\u975E\u767D\u540D\u5355"],
        horizontal=True,
        key='tg_broadcast_filter',
    )

    if st.button("\U0001F4E5 \u52A0\u8F7D群组", use_container_width=True, key='tg_load_groups'):
        cache = load_tg_group_cache()
        rows = []
        for chat_id_str, detail in cache.items():
            try:
                chat_id = int(chat_id_str)
            except Exception:
                continue
            if filter_mode == "\u4EC5\u767D\u540D\u5355" and chat_id not in selected_group_ids:
                continue
            if filter_mode == "\u975E\u767D\u540D\u5355" and chat_id in selected_group_ids:
                continue
            title = detail.get("title") or "Unknown"
            last_seen = detail.get("last_seen") or ""
            rows.append({"name": title, "id": chat_id, "last_seen": last_seen})
        rows.sort(key=lambda r: (r["name"] or "").lower())
        st.session_state.tg_broadcast_groups = rows
        if rows:
            st.success("\u2705 \u52A0\u8F7D成功，找到 {} 个群组".format(len(rows)))
        else:
            st.info("\u672a找到可用群组，请先让机器人接收群消息后再进入群发。")

    groups = st.session_state.tg_broadcast_groups
    display_map = {}
    if groups:
        for row in groups:
            label = "{} ({})".format(row["name"], row["id"])
            display_map[label] = row
        options = list(display_map.keys())
        current = st.session_state.get('tg_broadcast_targets', [])
        if any(opt not in options for opt in current):
            st.session_state['tg_broadcast_targets'] = [opt for opt in current if opt in options]
        selected_labels = st.multiselect(
            "\u9009择群组（可多选）",
            options=list(display_map.keys()),
            default=list(display_map.keys()),
            key='tg_broadcast_targets',
        )
        col_a, col_b, col_c = st.columns(3)
        with col_a:
            if st.button("\u5168\u9009", key="tg_select_all"):
                st.session_state['tg_broadcast_targets'] = list(display_map.keys())
                st.rerun()
        with col_b:
            if st.button("\u53d6\u6d88\u5168\u9009", key="tg_select_none"):
                st.session_state['tg_broadcast_targets'] = []
                st.rerun()
        with col_c:
            if st.button("\u53cd\u9009", key="tg_select_invert"):
                current = set(st.session_state.get('tg_broadcast_targets', []))
                all_opts = list(display_map.keys())
                st.session_state['tg_broadcast_targets'] = [opt for opt in all_opts if opt not in current]
                st.rerun()
    else:
        st.info("\u8BF7点击加载群组，然后进行选择。")
        selected_labels = []

    st.divider()
    st.subheader("2\uFE0F\u20E3 \u8F93\u5165\u6D88\u606F\u5185\u5BB9")
    message_content = st.text_area(
        "\u6D88\u606F\u5185\u5BB9",
        placeholder="\u8F93\u5165要群发的消息...",
        height=150,
        key='tg_broadcast_message',
    )
    interval_sec = st.number_input(
        "\u7FA4\u53D1\u95F4\u9694（秒）",
        min_value=0,
        value=3,
        step=1,
        key='tg_broadcast_interval',
    )

    st.divider()
    st.subheader("3\uFE0F\u20E3 \u5F00\u59CB\u7FA4\u53D1")

    selected_rows = [display_map[label] for label in selected_labels if label in display_map]
    selected_ids = [row["id"] for row in selected_rows]
    id_name_map = {row["id"]: row["name"] for row in selected_rows}

    if not groups:
        st.info("\u8BF7先加载群组列表")
    elif not selected_ids:
        st.info("\u8BF7选择至少一个群组")
    elif not message_content.strip():
        st.info("\u8BF7输入消息内容")
    else:
        col1, col2 = st.columns([3, 1])
        with col1:
            st.text("\u51c6\u5907发送到 {} 个群组".format(len(selected_ids)))
        with col2:
            if st.button("\U0001F680 \u5F00\u59CB\u7FA4\u53D1", type='primary', use_container_width=True, key='tg_start_broadcast'):
                progress_bar = st.progress(0)
                status_text = st.empty()
                def update_progress(current, total, message):
                    progress = current / total
                    progress_bar.progress(progress)
                    status_text.text("[{} / {}] {}".format(current, total, message))
                try:
                    loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(loop)
                    success, failed, records = loop.run_until_complete(
                        send_broadcast_ids_with_interval(
                            selected_ids,
                            id_name_map,
                            message_content,
                            int(interval_sec),
                            update_progress,
                        )
                    )
                    loop.close()
                    st.session_state.tg_broadcast_records = records
                    st.success("\u2705 \u7FA4发完成！成功: {}, 失败: {}".format(success, failed))
                except Exception as e:
                    st.error("\u274C \u7FA4发失败: {}".format(e))

    if st.session_state.tg_broadcast_records:
        st.subheader("\u53D1送记录")
        st.dataframe(st.session_state.tg_broadcast_records, use_container_width=True)


def render_telegram_logs():
    """Telegram 日志界面"""
    from admin import read_log_file, LOG_DIR, SYSTEM_LOG_FILE, PRIVATE_LOG_FILE, GROUP_LOG_FILE
    st.subheader("📜 运行日志")
    st.caption("系统、私聊、群聊日志分类展示")

    log_tab1, log_tab2, log_tab3 = st.tabs(["系统日志", "私聊日志", "群聊日志"])
    col_a, col_b = st.columns([3, 1])
    with col_b:
        if st.button("刷新", use_container_width=True, key="tg_refresh_logs"):
            st.rerun()
    with log_tab1:
        logs = read_log_file(SYSTEM_LOG_FILE, 200)
        st.text_area("系统日志", value=logs, height=400, disabled=True)
        if st.button("清空系统日志", use_container_width=True, key="tg_clear_system_log"):
            os.makedirs(LOG_DIR, exist_ok=True)
            open(SYSTEM_LOG_FILE, 'w').close()
            st.success("已清空系统日志")
            st.rerun()
    with log_tab2:
        logs = read_log_file(PRIVATE_LOG_FILE, 200)
        st.text_area("私聊日志", value=logs, height=400, disabled=True)
        if st.button("清空私聊日志", use_container_width=True, key="tg_clear_private_log"):
            os.makedirs(LOG_DIR, exist_ok=True)
            open(PRIVATE_LOG_FILE, 'w').close()
            st.success("已清空私聊日志")
            st.rerun()
    with log_tab3:
        logs = read_log_file(GROUP_LOG_FILE, 200)
        st.text_area("群聊日志", value=logs, height=400, disabled=True)
        if st.button("清空群聊日志", use_container_width=True, key="tg_clear_group_log"):
            os.makedirs(LOG_DIR, exist_ok=True)
            open(GROUP_LOG_FILE, 'w').close()
            st.success("已清空群聊日志")
            st.rerun()


def render_telegram_stats():
    """Telegram 统计界面"""
    st.subheader("📊 使用统计")
    
    # 读取统计数据
    try:
        import json
        from datetime import datetime
        with open("platforms/telegram/stats.json", 'r', encoding='utf-8') as f:
            stats = json.load(f)
        
        # 计算成功率
        success_rate = 0
        if stats['total_replies'] > 0:
            success_rate = (stats['success_count'] / stats['total_replies']) * 100
        
        # 显示统计
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric("总消息数", stats['total_messages'])
        
        with col2:
            st.metric("总回复数", stats['total_replies'])
        
        with col3:
            st.metric("成功率", f"{success_rate:.1f}%")
        
        with col4:
            st.metric("失败次数", stats['error_count'])
        
        st.divider()
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.metric("私聊消息", stats['private_messages'])
        
        with col2:
            st.metric("群聊消息", stats['group_messages'])
        
        # 运行时间
        if stats.get('start_time'):
            start_time = datetime.fromisoformat(stats['start_time'])
            running_time = datetime.now() - start_time
            days = running_time.days
            hours = running_time.seconds // 3600
            minutes = (running_time.seconds % 3600) // 60
            
            st.divider()
            st.info(f"⏱️ 运行时长: {days}天 {hours}小时 {minutes}分钟")
        
        if stats.get('last_active'):
            last_active = datetime.fromisoformat(stats['last_active'])
            st.caption(f"最后活跃: {last_active.strftime('%Y-%m-%d %H:%M:%S')}")
        
        # 重置按钮
        if st.button("🗑️ 重置统计", use_container_width=True):
            default_stats = {
                "total_messages": 0,
                "total_replies": 0,
                "private_messages": 0,
                "group_messages": 0,
                "success_count": 0,
                "error_count": 0,
                "start_time": datetime.now().isoformat(),
                "last_active": None
            }
            with open("platforms/telegram/stats.json", 'w', encoding='utf-8') as f:
                json.dump(default_stats, f, indent=2, ensure_ascii=False)
            st.success("✅ 统计已重置")
            st.rerun()
        
    except Exception as e:
        st.error(f"读取统计失败: {e}")
        st.info("💡 统计数据将在机器人运行后生成")

# ==================== WhatsApp 面板 ====================

def get_whatsapp_status():
    """获取 WhatsApp 机器人运行状态"""
    pid_file = "platforms/whatsapp/bot.pid"
    try:
        if os.path.exists(pid_file):
            with open(pid_file, 'r') as f:
                pid = int(f.read().strip())
            try:
                import psutil
                if psutil.pid_exists(pid):
                    return True, pid
            except:
                pass
        return False, None
    except:
        return False, None

def start_whatsapp_bot():
    """启动 WhatsApp 机器人"""
    try:
        # 检查 Node.js
        import subprocess
        result = subprocess.run(['node', '--version'], capture_output=True, text=True)
        if result.returncode != 0:
            return False, "❌ 未检测到 Node.js，请先安装"
        
        # 检查依赖
        if not os.path.exists("platforms/whatsapp/node_modules"):
            return False, "❌ 请先运行 install.bat/sh 安装依赖"
        
        # 启动机器人
        whatsapp_dir = "platforms/whatsapp"
        log_file = os.path.join(whatsapp_dir, "bot.log")
        pid_file = os.path.join(whatsapp_dir, "bot.pid")
        
        # 清理旧文件（避免权限问题）
        try:
            if os.path.exists(log_file):
                os.remove(log_file)
            if os.path.exists(pid_file):
                os.remove(pid_file)
        except:
            pass
        
        # 使用 'a' 模式而不是 'w'，避免权限问题
        log_handle = open(log_file, 'a', encoding='utf-8', buffering=1)
        
        if sys.platform == 'win32':
            process = subprocess.Popen(
                ['node', 'bot.js'],
                cwd=whatsapp_dir,
                stdout=log_handle,
                stderr=subprocess.STDOUT,
                creationflags=subprocess.CREATE_NO_WINDOW
            )
        else:
            process = subprocess.Popen(
                ['node', 'bot.js'],
                cwd=whatsapp_dir,
                stdout=log_handle,
                stderr=subprocess.STDOUT
            )
        
        # 保存 PID
        with open(pid_file, 'w') as f:
            f.write(str(process.pid))
        
        # 注意：不要关闭 log_handle，让进程继续使用
        
        return True, f"✅ WhatsApp 机器人已启动 (PID: {process.pid})"
    except Exception as e:
        return False, f"❌ 启动失败: {str(e)}"

def stop_whatsapp_bot():
    """停止 WhatsApp 机器人"""
    pid_file = "platforms/whatsapp/bot.pid"
    try:
        if os.path.exists(pid_file):
            with open(pid_file, 'r') as f:
                pid = int(f.read().strip())
            
            import psutil
            if psutil.pid_exists(pid):
                process = psutil.Process(pid)
                process.terminate()
                process.wait(timeout=5)
            
            os.remove(pid_file)
            return True, "✅ WhatsApp 机器人已停止"
        else:
            return False, "⚠️ 机器人未在运行"
    except Exception as e:
        return False, f"❌ 停止失败: {str(e)}"

def render_whatsapp_panel():
    """WhatsApp 主面板"""
    st.header("💬 WhatsApp 自动回复机器人")
    
    # 检查是否有二维码需要显示
    qr_image_path = "platforms/whatsapp/qr_code.png"
    status_file_path = "platforms/whatsapp/login_status.json"
    
    # 显示二维码弹窗
    if os.path.exists(qr_image_path) and os.path.exists(status_file_path):
        try:
            import json
            with open(status_file_path, 'r') as f:
                login_status = json.load(f)
            
            if login_status.get('status') == 'waiting' and login_status.get('qr_available'):
                with st.expander("📱 WhatsApp 登录二维码", expanded=True):
                    st.info("请使用手机 WhatsApp 扫描下方二维码登录")
                    st.image(qr_image_path, caption="扫描此二维码登录", width=400)
                    st.caption("提示：打开 WhatsApp > 设置 > 已连接的设备 > 连接设备")
                    st.caption("⏳ 二维码有效期约 20 秒，过期请重启机器人")
                    
                    if st.button("🔄 刷新查看状态", key="refresh_qr"):
                        st.rerun()
        except Exception as e:
            st.error(f"读取登录状态失败: {e}")
    
    # 状态显示
    col1, col2, col3 = st.columns(3)
    
    with col1:
        is_running, pid = get_whatsapp_status()
        if is_running:
            st.success(f"🟢 运行中 (PID: {pid})")
        else:
            st.error("🔴 已停止")
    
    with col2:
        if os.path.exists("platforms/whatsapp/.wwebjs_auth"):
            st.success("✅ 已登录")
        else:
            st.warning("⚠️ 未登录")
    
    with col3:
        if os.path.exists(".env"):
            st.success("✅ 已配置")
        else:
            st.error("❌ 未配置")
    
    st.divider()
    
    # 控制按钮
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if st.button("🚀 启动机器人", use_container_width=True, type="primary", 
                    disabled=is_running, key="whatsapp_start"):
            success, message = start_whatsapp_bot()
            if success:
                st.success(message)
                st.rerun()
            else:
                st.error(message)
    
    with col2:
        if st.button("⛔ 停止机器人", use_container_width=True, 
                    disabled=not is_running, key="whatsapp_stop"):
            success, message = stop_whatsapp_bot()
            if success:
                st.success(message)
                st.rerun()
            else:
                st.error(message)
    
    with col3:
        if st.button("🔄 重启机器人", use_container_width=True,
                    disabled=not is_running, key="whatsapp_restart"):
            stop_whatsapp_bot()
            import time
            time.sleep(1)
            start_whatsapp_bot()
            st.success("机器人已重启")
            st.rerun()
    
    st.divider()
    
    # Tab 界面
    tab1, tab2, tab3 = st.tabs([
        "🧠 配置", "📜 日志", "📊 统计"
    ])
    
    with tab1:
        render_whatsapp_config()
    
    with tab2:
        render_whatsapp_logs()
    
    with tab3:
        render_whatsapp_stats()

def render_whatsapp_config():
    """WhatsApp 配置界面"""
    from admin import read_file, write_file
    
    st.subheader("⚙️ 配置管理")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("**AI 人设**")
        prompt = st.text_area(
            "编辑提示词",
            value=read_file("platforms/whatsapp/prompt.txt", "你是一个幽默的助手"),
            height=200,
            key="wa_prompt"
        )
        if st.button("💾 保存人设", key="wa_save_prompt"):
            write_file("platforms/whatsapp/prompt.txt", prompt)
            st.success("✅ 已保存")
    
    with col2:
        st.markdown("**触发关键词**")
        keywords = st.text_area(
            "群聊关键词（每行一个）",
            value=read_file("platforms/whatsapp/keywords.txt", "帮我\n求助\nAI"),
            height=200,
            key="wa_keywords"
        )
        if st.button("💾 保存关键词", key="wa_save_keywords"):
            write_file("platforms/whatsapp/keywords.txt", keywords)
            st.success("✅ 已保存")
    
    st.divider()
    
    st.markdown("**功能开关**")
    config_content = read_file("platforms/whatsapp/config.txt", "PRIVATE_REPLY=on\nGROUP_REPLY=on")
    
    col1, col2 = st.columns(2)
    
    with col1:
        private_reply = "on" if "PRIVATE_REPLY=on" in config_content else "off"
        private_enabled = st.toggle("私聊回复", value=(private_reply=="on"), key="wa_private")
    
    with col2:
        group_reply = "on" if "GROUP_REPLY=on" in config_content else "off"
        group_enabled = st.toggle("群聊回复", value=(group_reply=="on"), key="wa_group")
    
    if st.button("💾 保存开关配置", key="wa_save_config"):
        new_config = f"PRIVATE_REPLY={'on' if private_enabled else 'off'}\nGROUP_REPLY={'on' if group_enabled else 'off'}"
        write_file("platforms/whatsapp/config.txt", new_config)
        st.success("✅ 已保存")
    
    st.info("💡 修改后立即生效，无需重启机器人")

def render_whatsapp_logs():
    """WhatsApp 日志界面"""
    st.subheader("📜 运行日志")
    
    log_file = "platforms/whatsapp/bot.log"
    
    col1, col2 = st.columns([3, 1])
    
    with col1:
        if os.path.exists(log_file):
            file_size = os.path.getsize(log_file)
            last_modified = datetime.fromtimestamp(os.path.getmtime(log_file))
            st.caption(f"📁 文件大小: {file_size} 字节 | 📅 最后更新: {last_modified.strftime('%Y-%m-%d %H:%M:%S')}")
    
    with col2:
        if st.button("🔄 刷新日志", use_container_width=True, key="wa_refresh"):
            st.rerun()
    
    try:
        if os.path.exists(log_file):
            with open(log_file, 'r', encoding='utf-8', errors='ignore') as f:
                logs = f.read()
            
            if logs.strip():
                st.code(logs, language="log", line_numbers=False)
            else:
                st.info("📝 日志为空，等待机器人产生输出...")
        else:
            st.warning("⚠️ 日志文件不存在，请先启动机器人")
    except Exception as e:
        st.error(f"❌ 读取日志失败: {e}")
    
    if st.button("🗑️ 清空日志", key="wa_clear"):
        try:
            with open(log_file, 'w') as f:
                f.write("")
            st.success("✅ 日志已清空")
            st.rerun()
        except:
            st.error("❌ 清空失败")

def render_whatsapp_stats():
    """WhatsApp 统计界面"""
    st.subheader("📊 使用统计")
    
    # 读取统计数据
    try:
        import json
        from datetime import datetime
        with open("platforms/whatsapp/stats.json", 'r', encoding='utf-8') as f:
            stats = json.load(f)
        
        # 计算成功率
        success_rate = 0
        if stats['total_replies'] > 0:
            success_rate = (stats['success_count'] / stats['total_replies']) * 100
        
        # 显示统计
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric("总消息数", stats['total_messages'])
        
        with col2:
            st.metric("总回复数", stats['total_replies'])
        
        with col3:
            st.metric("成功率", f"{success_rate:.1f}%")
        
        with col4:
            st.metric("失败次数", stats['error_count'])
        
        st.divider()
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.metric("私聊消息", stats['private_messages'])
        
        with col2:
            st.metric("群聊消息", stats['group_messages'])
        
        # 运行时间
        if stats.get('start_time'):
            start_time = datetime.fromisoformat(stats['start_time'])
            running_time = datetime.now() - start_time
            days = running_time.days
            hours = running_time.seconds // 3600
            minutes = (running_time.seconds % 3600) // 60
            
            st.divider()
            st.info(f"⏱️ 运行时长: {days}天 {hours}小时 {minutes}分钟")
        
        if stats.get('last_active'):
            last_active = datetime.fromisoformat(stats['last_active'])
            st.caption(f"最后活跃: {last_active.strftime('%Y-%m-%d %H:%M:%S')}")
        
        # 重置按钮
        if st.button("🗑️ 重置统计", use_container_width=True, key="wa_reset_stats"):
            default_stats = {
                "total_messages": 0,
                "total_replies": 0,
                "private_messages": 0,
                "group_messages": 0,
                "success_count": 0,
                "error_count": 0,
                "start_time": datetime.now().isoformat(),
                "last_active": None
            }
            with open("platforms/whatsapp/stats.json", 'w', encoding='utf-8') as f:
                json.dump(default_stats, f, indent=2, ensure_ascii=False)
            st.success("✅ 统计已重置")
            st.rerun()
        
    except Exception as e:
        st.error(f"读取统计失败: {e}")
        st.info("💡 统计数据将在机器人运行后生成")

def render_coming_soon_panel(platform_name, platform_info):
    """渲染开发中的平台面板"""
    st.header(f"{platform_info['icon']} {platform_name} - 开发中")
    
    st.info(f"""
    ### 🚧 平台开发中
    
    **{platform_name}** 功能正在开发中，敬请期待！
    
    **计划功能：**
    - ✅ 自动回复
    - ✅ 上下文记忆
    - ✅ 群发消息
    - ✅ Web 管理
    - ✅ 统计报表
    
    **预计上线：** 待定
    
    ---
    
    💡 如果你急需此平台支持，请联系开发者。
    """)
    
    # 开发进度
    st.markdown("### 📈 开发进度")
    
    progress_data = {
        'whatsapp': 30,
        'facebook': 10,
        'messenger': 10,
        'wechat': 5,
        'instagram': 5,
        'twitter': 5,
        'discord': 5
    }
    
    progress = progress_data.get(platform_info.get('id', ''), 0)
    st.progress(progress / 100)
    st.caption(f"完成度: {progress}%")

def main():
    if 'show_login_panel' not in st.session_state:
        st.session_state.show_login_panel = False

    """主函数"""
    # 标题
    st.markdown('<div class="main-header">👑鼎盛👑内部工具</div>', 
                unsafe_allow_html=True)
    
    # 初始化 session state
    if 'selected_platform' not in st.session_state:
        st.session_state.selected_platform = 'telegram'
    
    # 左侧平台选择器
    selected_platform = render_platform_selector()
    
    # 侧边栏底部信息
    st.sidebar.markdown("---")
    st.sidebar.markdown("### 📊 系统信息")
    st.sidebar.caption(f"Python: {sys.version.split()[0]}")
    st.sidebar.caption(f"Streamlit: {st.__version__}")
    
    # 右侧主面板
    platform_info = PLATFORMS[selected_platform]
    
    if platform_info['status'] == 'available':
        if selected_platform == 'telegram':
            render_telegram_panel()
        elif selected_platform == 'whatsapp':
            render_whatsapp_panel()
        else:
            render_coming_soon_panel(platform_info['name'], {**platform_info, 'id': selected_platform})
    else:
        render_coming_soon_panel(platform_info['name'], {**platform_info, 'id': selected_platform})
    
    # 页脚
    st.markdown("---")
    st.caption("💡 提示：点击左侧选择不同的社交媒体平台")

if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        st.error(f"❌ 程序错误: {e}")
        import traceback
        st.code(traceback.format_exc())

import asyncio
import os
import sys
import random
import json
from datetime import datetime
import httpx # 必须确保已安装: pip install httpx
from telethon import TelegramClient, events
from openai import AsyncOpenAI
from dotenv import load_dotenv

# --- 1. 基础设置 ---
# 解决 Windows 控制台乱码
if sys.platform == 'win32':
    try:
        import codecs
        sys.stdout.reconfigure(encoding='utf-8')
        sys.stderr.reconfigure(encoding='utf-8')
    except:
        pass

load_dotenv()

# --- Logging (system / private / group) ---
LOG_DIR = os.path.join("platforms", "telegram", "logs")
SYSTEM_LOG_FILE = os.path.join(LOG_DIR, "system.log")
PRIVATE_LOG_FILE = os.path.join(LOG_DIR, "private.log")
GROUP_LOG_FILE = os.path.join(LOG_DIR, "group.log")

def _append_log(file_path, message):
    os.makedirs(os.path.dirname(file_path), exist_ok=True)
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open(file_path, "a", encoding="utf-8") as f:
        f.write(f"[{ts}] {message}\n")

def log_system(message):
    _append_log(SYSTEM_LOG_FILE, message)
    print(message)

def log_private(message):
    _append_log(PRIVATE_LOG_FILE, message)
    print(message)

def log_group(message):
    _append_log(GROUP_LOG_FILE, message)
    print(message)

# --- 2. 加载配置 & 自动修复错误 ---
TELEGRAM_API_ID = os.getenv('TELEGRAM_API_ID')
TELEGRAM_API_HASH = os.getenv('TELEGRAM_API_HASH')
AI_API_KEY = os.getenv('AI_API_KEY')
AI_BASE_URL = os.getenv('AI_BASE_URL')
AI_MODEL_NAME = os.getenv('AI_MODEL_NAME')

# 🔍【自动修复功能】防止 .env 填错
if AI_BASE_URL:
    # 1. 如果忘了写 https://，自动补上
    if not AI_BASE_URL.startswith("http"):
        AI_BASE_URL = f"https://{AI_BASE_URL}"
    
    # 2. 【关键修复】将错误域名 55.ai 替换为正确的 api.55.ai
    if "://55.ai" in AI_BASE_URL:
        AI_BASE_URL = AI_BASE_URL.replace("://55.ai", "://api.55.ai")
        log_system("⚠️ 检测到旧域名，已自动修正为 api.55.ai")
    
    # 3. 如果多写了 /chat/completions，自动去掉（OpenAI SDK 会自动拼接）
    if "/chat/completions" in AI_BASE_URL:
        AI_BASE_URL = AI_BASE_URL.replace("/chat/completions", "")
    
    # 4. 确保以 /v1 结尾（根据 API 规范）
    if not AI_BASE_URL.endswith("/v1"):
        AI_BASE_URL = AI_BASE_URL.rstrip("/") + "/v1"

log_system(f"🔧 AI 接口地址已修正为: {AI_BASE_URL}")

# --- 3. 初始化客户端 (抗干扰模式) ---

# 创建一个忽略证书错误的 HTTP 客户端 (解决 SSL Error)
http_client = httpx.AsyncClient(verify=False)

ai_client = AsyncOpenAI(
    api_key=AI_API_KEY,
    base_url=AI_BASE_URL,
    http_client=http_client # 强制使用这个客户端
)

client = TelegramClient('userbot_session', int(TELEGRAM_API_ID), TELEGRAM_API_HASH)

# 【已移除硬编码】现在提示词从 prompt.txt 文件动态加载
# SYSTEM_PROMPT = """..."""

# --- 4. 核心逻辑 ---

def load_system_prompt():
    """
    热更新功能：从 prompt.txt 读取 AI 提示词
    这样可以在程序运行时随时修改 AI 人设，无需重启
    """
    prompt_file = "platforms/telegram/prompt.txt"
    default_prompt = "你是一个幽默、专业的个人助理，帮机主回复消息。请用自然、友好的语气回复。"
    
    try:
        with open(prompt_file, 'r', encoding='utf-8') as f:
            content = f.read().strip()
            if content:
                return content
            else:
                return default_prompt
    except FileNotFoundError:
        log_system(f"⚠️ 未找到 {prompt_file}，使用默认提示词")
        return default_prompt
    except Exception as e:
        log_system(f"⚠️ 读取 {prompt_file} 失败: {e}，使用默认提示词")
        return default_prompt

def load_keywords():
    """
    热更新功能：从 keywords.txt 读取群聊触发关键词
    每次处理消息时重新读取，实现实时更新
    """
    keywords_file = "platforms/telegram/keywords.txt"
    keywords = []
    
    try:
        with open(keywords_file, 'r', encoding='utf-8') as f:
            for line in f:
                keyword = line.strip()
                # 忽略空行和注释行（以 # 开头）
                if keyword and not keyword.startswith('#'):
                    keywords.append(keyword)
        return keywords
    except FileNotFoundError:
        # 文件不存在时返回空列表（群聊只能通过 @ 触发）
        return []
    except Exception as e:
        log_system(f"⚠️ 读取 {keywords_file} 失败: {e}")
        return []


# ===== Q&A Knowledge Base (Telegram) =====
def load_qa_pairs(file_path):
    qa_pairs = []
    if not file_path or (not os.path.exists(file_path)):
        return qa_pairs
    try:
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            lines = [ln.strip() for ln in f if ln.strip() and (not ln.strip().startswith('#'))]
        for line in lines:
            if '||' in line:
                q, a = line.split('||', 1)
                q = q.strip()
                a = a.strip()
                if q and a:
                    qa_pairs.append((q, a))
    except Exception:
        return []
    return qa_pairs

def match_qa_reply(message_text, qa_pairs):
    if not message_text:
        return None
    msg = message_text.strip().lower()
    if not msg:
        return None
    for q, a in qa_pairs:
        if q and (q.strip().lower() in msg):
            return a
    return None

def load_config():
    """
    热更新功能：从 config.txt 读取功能开关配置
    返回配置字典
    """
    config_file = "platforms/telegram/config.txt"
    config = {
        'PRIVATE_REPLY': True,   # 默认开启私聊回复
        'GROUP_REPLY': True,     # 默认开启群聊回复
        'GROUP_CONTEXT': False   # 是否在群聊中开启上下文自动回复（无关键词＋未被 @ 时也可回复）
    }
    
    try:
        with open(config_file, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                # 跳过空行和注释
                if not line or line.startswith('#'):
                    continue
                
                # 解析配置行：KEY=VALUE
                if '=' in line:
                    key, value = line.split('=', 1)
                    key = key.strip()
                    value = value.strip().lower()
                    
                    # 转换为布尔值
                    if key in config:
                        config[key] = (value == 'on')
        
        return config
    except FileNotFoundError:
        log_system(f"⚠️ 未找到 {config_file}，使用默认配置")
        return config
    except Exception as e:
        log_system(f"⚠️ 读取 {config_file} 失败: {e}，使用默认配置")
        return config

TG_PLATFORM_DIR = "platforms/telegram"
GROUP_CACHE_FILE = os.path.join(TG_PLATFORM_DIR, "group_cache.json")
SELECTED_GROUPS_FILE = os.path.join(TG_PLATFORM_DIR, "selected_groups.json")

def load_group_cache():
    try:
        with open(GROUP_CACHE_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
            if isinstance(data, dict):
                return data
    except:
        pass
    return {}

def save_group_cache(cache):
    os.makedirs(os.path.dirname(GROUP_CACHE_FILE), exist_ok=True)
    with open(GROUP_CACHE_FILE, 'w', encoding='utf-8') as f:
        json.dump(cache, f, ensure_ascii=False, indent=2)

async def record_group(event):
    if not event.is_group:
        return
    chat_id = getattr(event, 'chat_id', None)
    if chat_id is None:
        return
    chat_id_str = str(chat_id)
    cache = load_group_cache()
    chat_obj = getattr(event, 'chat', None) or getattr(event.message, 'chat', None)
    title = ""
    if chat_obj:
        title = getattr(chat_obj, 'title', None) or getattr(chat_obj, 'name', None) or ""
    else:
        try:
            chat = await event.get_chat()
            title = getattr(chat, 'title', None) or getattr(chat, 'name', None) or ""
        except:
            title = ""
    entry = dict(cache.get(chat_id_str, {}))
    entry['title'] = title or entry.get('title', '')
    entry['last_seen'] = datetime.now().isoformat()
    cache[chat_id_str] = entry
    save_group_cache(cache)
    descriptor = title or str(chat_id)
    log_system(f"🗂️ 缓存群聊: {descriptor} ({chat_id})")

def load_selected_group_ids():
    try:
        with open(SELECTED_GROUPS_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
        raw_ids = data.get('selected_ids', [])
        result = set()
        for raw in raw_ids:
            try:
                result.add(int(raw))
            except:
                pass
        return result
    except:
        return set()


def load_stats():
    """加载统计数据"""
    stats_file = "platforms/telegram/stats.json"
    default_stats = {
        "total_messages": 0,
        "total_replies": 0,
        "private_messages": 0,
        "group_messages": 0,
        "success_count": 0,
        "error_count": 0,
        "start_time": datetime.now().isoformat(),
        "last_active": None
    }
    
    try:
        with open(stats_file, 'r', encoding='utf-8') as f:
            stats = json.load(f)
            if stats.get('start_time') is None:
                stats['start_time'] = datetime.now().isoformat()
            return stats
    except:
        return default_stats

def save_stats(stats):
    """保存统计数据"""
    stats_file = "platforms/telegram/stats.json"
    try:
        stats['last_active'] = datetime.now().isoformat()
        with open(stats_file, 'w', encoding='utf-8') as f:
            json.dump(stats, f, indent=2, ensure_ascii=False)
    except Exception as e:
        log_system(f"⚠️ 保存统计失败: {e}")

async def get_chat_history(chat_id, limit=8, max_id=0):
    """获取聊天上下文"""
    messages = []
    try:
        async for msg in client.iter_messages(chat_id, limit=limit, max_id=max_id):
            if msg.text:
                role = "assistant" if msg.out else "user"
                messages.append({"role": role, "content": msg.text})
        return messages[::-1]
    except Exception:
        return []

@client.on(events.NewMessage(incoming=True))
async def handler(event):
    # 只处理有文本内容的消息
    if not event.message.text:
        return
    
    # 加载统计数据
    stats = load_stats()
    stats['total_messages'] += 1
    
    msg = event.message.text
    sender = await event.get_sender()
    name = getattr(sender, 'first_name', '朋友')
    
    # 【热更新】实时读取配置
    config = load_config()
    keywords = load_keywords()
    context_reply_enabled = config.get('GROUP_CONTEXT', False)
    
    # 记录消息类型
    if event.is_private:
        stats['private_messages'] += 1
    elif event.is_group:
        stats['group_messages'] += 1
    
    # 【功能开关检查】
    if event.is_private and not config['PRIVATE_REPLY']:
        # 私聊回复已关闭
        log_private(f"🔕 私聊回复已关闭，忽略消息 [{name}]: {msg}")
        return
    
    if event.is_group and not config['GROUP_REPLY']:
        # 群聊回复已关闭
        log_group(f"🔕 群聊回复已关闭，忽略消息 [{name}]: {msg}")
        return

    if event.is_group:
        await record_group(event)
        selected_group_ids = load_selected_group_ids()
        if selected_group_ids:
            chat_id = getattr(event, 'chat_id', None)
            if chat_id is None or int(chat_id) not in selected_group_ids:
                chat_obj = getattr(event, 'chat', None) or getattr(event.message, 'chat', None)
                chat_name = getattr(chat_obj, 'title', None) or getattr(chat_obj, 'name', None) if chat_obj else ""
                descriptor = chat_name or str(chat_id)
                log_group(f"🛑 群聊 [{descriptor}] 不在白名单，跳过回复")
                return
    
    # 【智能触发逻辑】
    should_reply = False
    
    if event.is_private:
        # 私聊：直接回复（已经通过开关检查）
        should_reply = True
        log_private(f"📩 收到私聊 [{name}]: {msg}")
    elif event.is_group:
        # 群聊：需要满足以下任一条件（已经通过开关检查）
        if event.mentioned:
            # 条件1：被 @ 了
            should_reply = True
            log_group(f"📩 群聊被 @ [{name}]: {msg}")
        elif keywords:
            # 条件2：消息包含关键词
            for keyword in keywords:
                if keyword.lower() in msg.lower():
                    should_reply = True
                    log_group(f"📩 群聊触发关键词 [{keyword}] [{name}]: {msg}")
                    break
        elif context_reply_enabled:
            should_reply = True
            log_group(f"📩 群聊上下文触发 [{name}]: {msg}")
    
    # 如果不满足回复条件，直接返回
    if not should_reply:
        return

    async with client.action(event.chat_id, 'typing'):
        # 【热更新】每次处理消息前重新读取提示词
        system_prompt = load_system_prompt()
        
        # 获取历史记录（保持上下文）
        history = await get_chat_history(event.chat_id, max_id=event.id)
        qa_file = os.path.join(os.path.dirname(__file__), 'platforms', 'telegram', 'qa.txt')
        qa_pairs = load_qa_pairs(qa_file)
        qa_reply = match_qa_reply(msg, qa_pairs)
        if qa_reply:
            await event.reply(qa_reply)
            if event.is_private:
                log_private(f"[QA] reply: {qa_reply}")
            else:
                log_group(f"[QA] reply: {qa_reply}")
            return
        
        # 构造发给 AI 的数据
        messages = [{"role": "system", "content": system_prompt}] + history + [{"role": "user", "content": msg}]

        try:
            if event.is_private:
                log_private("🤖 AI 正在思考...")
            else:
                log_group("🤖 AI 正在思考...")
            response = await ai_client.chat.completions.create(
                model=AI_MODEL_NAME,
                messages=messages,
                temperature=0.7,
                max_tokens=500
            )
            reply = response.choices[0].message.content
            
            # 模拟打字延迟
            # 模拟真人思考和打字延迟（3-10秒）
            delay = random.uniform(3, 10)
            if event.is_private:
                log_private(f"⏳ 延迟 {delay:.1f} 秒后回复（模拟真人）")
            else:
                log_group(f"⏳ 延迟 {delay:.1f} 秒后回复（模拟真人）")
            await asyncio.sleep(delay)
            
            await event.reply(reply)
            if event.is_private:
                log_private(f"📤 已回复: {reply}")
            else:
                log_group(f"📤 已回复: {reply}")
            
            # 统计成功回复
            stats['total_replies'] += 1
            stats['success_count'] += 1
            save_stats(stats)
            
        except Exception as e:
            log_system(f"❌ AI 调用失败: {e}")
            # 统计失败
            stats['error_count'] += 1
            save_stats(stats)

# --- 5. 启动程序 ---
if __name__ == '__main__':
    log_system("🚀 程序启动中...")
    client.start()
    client.run_until_disconnected()
